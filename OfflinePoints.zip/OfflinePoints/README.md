# Mawqie (موقع)

An Android map app to import GPX points, keep them on the phone, and find them, in the style of Locus Map.

- Esri street and satellite maps (no API key); map tiles you have viewed are cached for offline use
- Red crosshair at the map center; center coordinates in the top bar
- Small point dots with Locus-style name labels (white box, grey border)
- Eye button on the map to hide or show all points at once
- Search by name (or description), nearest to the map center first, with an eye button per result
- My points: folders inside collapsible groups, with visible / total counts
- Folder ⋮ menu: Edit (group, icon, name, label mode, icon size, label size), Import, Export GPX, Delete
- Folder screen: eye per point, Display all / Hide all / First X / Invert, sort by Name, Distance, Created, Updated (+ reverse)
- Long-press to select points: Select all, Invert selection, Copy to folder, Move to folder
- Points are stored in a database inside the app and work without internet

Build: `.github/workflows/build.yml` (GitHub Actions). Test file: `sample_dubai.gpx`.
