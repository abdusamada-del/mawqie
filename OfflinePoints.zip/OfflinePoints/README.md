# Offline Points

An Android map app to import GPX points, store them on the phone, and search them,
in the style of Locus Map.

- OpenStreetMap street map + satellite layer (no API key needed)
- Red crosshair at the map center, center coordinates shown in the top bar
- Import a GPX file into a named folder; points are saved on the phone
- Point names shown as labels on the map (zoom in to see them)
- Search by name (optionally description), nearest to the map center first
- "My points" screen: show one folder on the map, or delete a folder
- Tap a point: copy coordinates or navigate with Google Maps

Offline: your points are always offline. Map pictures are cached as you
browse, so areas you have looked at before also work without internet.

Build: the GitHub Actions workflow in `.github/workflows/build.yml` builds the APK.
Test file: `sample_dubai.gpx`.
