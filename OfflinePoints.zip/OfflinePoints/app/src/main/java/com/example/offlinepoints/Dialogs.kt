package com.example.offlinepoints

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

object Dialogs {

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).roundToInt()

    /**
     * Shows a "Working… 45%" box while [work] runs in the background,
     * then calls [done] on the main thread.
     */
    fun <T> runWithProgress(
        activity: AppCompatActivity,
        title: String,
        work: ((Int) -> Unit) -> T,
        done: (Result<T>) -> Unit
    ) {
        val bar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val pct = TextView(activity).apply {
            gravity = Gravity.END
            text = "0%"
        }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 24), dp(activity, 8), dp(activity, 24), 0)
            addView(bar)
            addView(pct)
        }
        val dlg = AlertDialog.Builder(activity).setTitle(title).setView(box).setCancelable(false).create()
        dlg.show()
        activity.lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    work { p ->
                        activity.runOnUiThread {
                            bar.progress = p
                            pct.text = "$p%"
                        }
                    }
                }
            }
            if (dlg.isShowing) dlg.dismiss()
            done(result)
        }
    }

    fun askText(
        ctx: Context,
        title: String,
        initial: String,
        hint: String,
        number: Boolean = false,
        onOk: (String) -> Unit
    ) {
        val et = EditText(ctx).apply {
            setText(initial)
            this.hint = hint
            setSingleLine()
            if (number) inputType = InputType.TYPE_CLASS_NUMBER
            setSelectAllOnFocus(true)
        }
        val box = FrameLayout(ctx).apply {
            setPadding(dp(ctx, 20), dp(ctx, 8), dp(ctx, 20), 0)
            addView(et)
        }
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** "Move to" / "Copy to" folder list, with a New folder option at the top. */
    fun chooseFolder(activity: AppCompatActivity, title: String, exclude: String?, onChosen: (String) -> Unit) {
        val folders = Repo.folders()
            .filter { it.name != exclude }
            .sortedWith(compareBy<FolderInfo, String>(NaturalOrder) { it.group ?: "" }.thenBy(NaturalOrder) { it.name })
        val labels = arrayOf("+  New folder…") + folders.map { f ->
            (f.group?.let { "$it  ›  " } ?: "") + f.name + "    ${f.visibleCount} / ${f.total}"
        }
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setItems(labels) { _, which ->
                if (which == 0) {
                    askText(activity, "New folder", "", "Folder name") { name ->
                        Repo.createFolder(name)
                        onChosen(name)
                    }
                } else {
                    onChosen(folders[which - 1].name)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Import GPX ───────────────────────────────────────────────────────────

    private fun fileName(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    /** Asks which folder to import into, then imports with a progress bar. */
    fun importGpx(
        activity: AppCompatActivity,
        uri: Uri,
        presetFolder: String? = null,
        onImported: (folder: String, count: Int) -> Unit
    ) {
        val suggested = presetFolder
            ?: fileName(activity, uri)?.substringBeforeLast('.')?.takeIf { it.isNotBlank() }
            ?: "Imported"
        val pad = dp(activity, 20)
        val input = EditText(activity).apply {
            setText(suggested)
            setSelectAllOnFocus(true)
            setSingleLine()
        }
        val replace = CheckBox(activity).apply { text = "Replace the points if this folder already exists" }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
            addView(replace)
        }
        AlertDialog.Builder(activity)
            .setTitle("Import into folder")
            .setView(box)
            .setPositiveButton("Import") { _, _ ->
                val folder = input.text.toString().trim().ifEmpty { suggested }
                val doReplace = replace.isChecked
                runWithProgress(activity, "Importing…", { report ->
                    val pts = activity.contentResolver.openInputStream(uri)?.use { GpxParser.parse(it, folder) }
                        ?: error("Cannot open the file")
                    if (pts.isNotEmpty()) Repo.addPoints(folder, pts, doReplace, report)
                    pts.size
                }) { result ->
                    result.onSuccess { count ->
                        if (count == 0) {
                            Toast.makeText(activity, "No points found in this file", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(activity, "Imported $count points into \"$folder\"", Toast.LENGTH_LONG).show()
                            onImported(folder, count)
                        }
                    }.onFailure {
                        Toast.makeText(activity, "Import failed: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Icon picker ──────────────────────────────────────────────────────────

    fun iconPicker(ctx: Context, current: String, onPick: (String) -> Unit) {
        val span = 7
        val items = ArrayList<Pair<Boolean, String>>() // (is header, title or icon id)
        IconRegistry.sections.forEach { s ->
            items.add(true to s.title)
            s.ids.forEach { items.add(false to it) }
        }

        val rv = RecyclerView(ctx)
        val lm = GridLayoutManager(ctx, span)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (items[position].first) span else 1
        }
        rv.layoutManager = lm
        rv.setPadding(dp(ctx, 8), 0, dp(ctx, 8), 0)

        lateinit var dlg: AlertDialog
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemViewType(position: Int): Int = if (items[position].first) 0 else 1

            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val v: View = if (viewType == 0) {
                    TextView(ctx).apply {
                        setPadding(dp(ctx, 8), dp(ctx, 14), dp(ctx, 8), dp(ctx, 4))
                        setTextColor(0xFF1E76D0.toInt())
                        textSize = 13f
                        setTypeface(typeface, Typeface.BOLD)
                    }
                } else {
                    ImageView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 44))
                        scaleType = ImageView.ScaleType.CENTER
                    }
                }
                return object : RecyclerView.ViewHolder(v) {}
            }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val (header, value) = items[position]
                if (header) {
                    (holder.itemView as TextView).text = value.uppercase(Locale.US)
                } else {
                    val iv = holder.itemView as ImageView
                    val size = if (IconRegistry.isMarker(value)) dp(ctx, 18) else dp(ctx, 30)
                    iv.setImageBitmap(IconRegistry.bitmap(value, size))
                    iv.setBackgroundColor(if (value == current) 0x331E76D0 else 0)
                    iv.setOnClickListener {
                        onPick(value)
                        dlg.dismiss()
                    }
                }
            }

            override fun getItemCount(): Int = items.size
        }

        dlg = AlertDialog.Builder(ctx)
            .setTitle("Select icon")
            .setView(rv)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.show()
    }

    // ── Edit folder ──────────────────────────────────────────────────────────

    private fun iconScale(progress: Int) = 0.5f + progress * 0.1f
    private fun labelScale(progress: Int) = 0.6f + progress * 0.1f

    /** Small picture of how a point of this folder will look on the map. */
    fun previewBitmap(ctx: Context, icon: String, iconSize: Float, labelSize: Float, labelMode: Int): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val w = dp(ctx, 220)
        val h = dp(ctx, 80)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(0xFFF2EFE9.toInt())
        val ib = IconRegistry.bitmap(icon, (IconRegistry.baseSizeDp(icon) * iconSize * d).roundToInt().coerceAtLeast(4))
        val x = w / 2f
        val y = dp(ctx, 24).toFloat()
        c.drawBitmap(ib, x - ib.width / 2f, y - ib.height / 2f, null)
        if (labelMode == FolderInfo.LABEL_ALWAYS) {
            LabelPainter(d).draw(c, "PK13648", null, x, y + ib.height / 2f, labelSize, null)
        }
        return bmp
    }

    fun editFolder(activity: AppCompatActivity, folder: FolderInfo, isNew: Boolean = false, onSaved: () -> Unit) {
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_edit_folder, null)
        val spGroup = view.findViewById<Spinner>(R.id.spGroup)
        val ivIcon = view.findViewById<ImageView>(R.id.ivIcon)
        val etName = view.findViewById<EditText>(R.id.etName)
        val spLabel = view.findViewById<Spinner>(R.id.spLabel)
        val sbIcon = view.findViewById<SeekBar>(R.id.sbIconSize)
        val tvIcon = view.findViewById<TextView>(R.id.tvIconSize)
        val sbLabel = view.findViewById<SeekBar>(R.id.sbLabelSize)
        val tvLabel = view.findViewById<TextView>(R.id.tvLabelSize)
        val ivPreview = view.findViewById<ImageView>(R.id.ivPreview)

        var icon = folder.icon

        fun refresh() {
            ivIcon.setImageBitmap(IconRegistry.bitmap(icon, IconRegistry.listSizePx(activity, icon)))
            tvIcon.text = String.format(Locale.US, "Icon size: %.1f×", iconScale(sbIcon.progress))
            tvLabel.text = String.format(Locale.US, "Label size: %.1f×", labelScale(sbLabel.progress))
            ivPreview.setImageBitmap(
                previewBitmap(activity, icon, iconScale(sbIcon.progress), labelScale(sbLabel.progress), spLabel.selectedItemPosition)
            )
        }

        // Group
        val groupItems = ArrayList<String>()
        groupItems.add("No group")
        groupItems.addAll(Repo.groups())
        groupItems.add("New group…")
        val groupAdapter = ArrayAdapter(activity, android.R.layout.simple_spinner_dropdown_item, groupItems)
        spGroup.adapter = groupAdapter
        val startGroup = folder.group?.let { groupItems.indexOf(it) } ?: 0
        spGroup.setSelection(if (startGroup > 0) startGroup else 0)
        var lastGroupPos = spGroup.selectedItemPosition
        spGroup.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                if (position == groupItems.size - 1) {
                    spGroup.setSelection(lastGroupPos)
                    askText(activity, "New group", "", "Group name") { name ->
                        val existing = groupItems.indexOf(name)
                        if (existing in 1 until groupItems.size - 1) {
                            spGroup.setSelection(existing)
                        } else {
                            groupItems.add(groupItems.size - 1, name)
                            groupAdapter.notifyDataSetChanged()
                            spGroup.setSelection(groupItems.size - 2)
                        }
                        lastGroupPos = spGroup.selectedItemPosition
                    }
                } else {
                    lastGroupPos = position
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Icon & name
        etName.setText(folder.name)
        ivIcon.setOnClickListener {
            iconPicker(activity, icon) { picked ->
                icon = picked
                refresh()
            }
        }

        // Label mode
        spLabel.adapter = ArrayAdapter(
            activity, android.R.layout.simple_spinner_dropdown_item, listOf("Never", "On tap", "Always")
        )
        spLabel.setSelection(folder.labelMode.coerceIn(0, 2))
        spLabel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) = refresh()
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Sizes
        sbIcon.max = 20
        sbIcon.progress = ((folder.iconSize - 0.5f) / 0.1f).roundToInt().coerceIn(0, 20)
        sbLabel.max = 14
        sbLabel.progress = ((folder.labelSize - 0.6f) / 0.1f).roundToInt().coerceIn(0, 14)
        val sizeListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = refresh()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        sbIcon.setOnSeekBarChangeListener(sizeListener)
        sbLabel.setOnSeekBarChangeListener(sizeListener)

        refresh()

        AlertDialog.Builder(activity)
            .setTitle(if (isNew) "New folder" else "Edit folder")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString().trim().ifEmpty { folder.name }
                if (name.isEmpty()) {
                    Toast.makeText(activity, "Please type a folder name", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val gPos = spGroup.selectedItemPosition
                val group = if (gPos <= 0 || gPos >= groupItems.size - 1) null else groupItems[gPos]
                val info = FolderInfo(
                    name = name,
                    group = group,
                    icon = icon,
                    labelMode = spLabel.selectedItemPosition,
                    iconSize = iconScale(sbIcon.progress),
                    labelSize = labelScale(sbLabel.progress)
                )
                activity.lifecycleScope.launch {
                    val ok = withContext(Dispatchers.IO) { Repo.saveFolder(folder.name, info) }
                    if (!ok) Toast.makeText(activity, "A folder called \"$name\" already exists", Toast.LENGTH_LONG).show()
                    onSaved()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
