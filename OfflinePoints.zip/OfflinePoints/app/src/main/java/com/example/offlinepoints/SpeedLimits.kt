package com.example.offlinepoints

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Speed limit of the road you are on, looked up from OpenStreetMap (Overpass API)
 * every few hundred metres while you move. Needs internet; null when unknown.
 */
class SpeedLimits(private val userAgent: String) {

    companion object {
        private const val SEARCH_RADIUS_M = 35
        private const val REQUERY_DISTANCE_M = 150f
        private const val MIN_INTERVAL_MS = 8_000L
        private const val KEEP_LIMIT_DISTANCE_M = 600f
    }

    /** Current limit in km/h, or null if unknown. */
    @Volatile
    var limitKmh: Int? = null
        private set

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var busy = false
    private var lastQueryLat = Double.NaN
    private var lastQueryLon = Double.NaN
    private var lastQueryAt = 0L
    private var limitLat = 0.0
    private var limitLon = 0.0

    /** Call on every GPS fix. [onChange] runs on the main thread when the limit changes. */
    fun onLocation(lat: Double, lon: Double, bearing: Float?, onChange: () -> Unit) {
        // Forget an old limit once we are well away from where it was found
        if (limitKmh != null && Geo.distance(limitLat, limitLon, lat, lon) > KEEP_LIMIT_DISTANCE_M) {
            limitKmh = null
            onChange()
        }
        if (busy) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastQueryAt < MIN_INTERVAL_MS) return
        val far = lastQueryLat.isNaN() || Geo.distance(lastQueryLat, lastQueryLon, lat, lon) > REQUERY_DISTANCE_M
        if (!far) return

        busy = true
        lastQueryAt = now
        lastQueryLat = lat
        lastQueryLon = lon
        executor.execute {
            val found: Int? = try {
                query(lat, lon, bearing)
            } catch (e: Exception) {
                null // no internet or server busy: keep the previous limit
            }
            main.post {
                busy = false
                if (found != null) {
                    val newLimit = if (found > 0) found else null
                    limitLat = lat
                    limitLon = lon
                    if (newLimit != limitKmh) {
                        limitKmh = newLimit
                        onChange()
                    }
                }
            }
        }
    }

    /** Returns the limit of the best matching nearby road, 0 if none has a limit. Throws on network errors. */
    private fun query(lat: Double, lon: Double, bearing: Float?): Int {
        val q = String.format(
            Locale.US,
            "[out:json][timeout:10];way(around:%d,%.6f,%.6f)[highway][maxspeed];out tags geom;",
            SEARCH_RADIUS_M, lat, lon
        )
        val conn = URL("https://overpass-api.de/api/interpreter").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.doOutput = true
            conn.setRequestProperty("User-Agent", userAgent)
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.outputStream.use { it.write(("data=" + URLEncoder.encode(q, "UTF-8")).toByteArray()) }
            if (conn.responseCode != 200) throw IOException("HTTP " + conn.responseCode)
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val elements = JSONObject(body).optJSONArray("elements") ?: return 0

            var best = 0
            var bestScore = Double.MAX_VALUE
            for (i in 0 until elements.length()) {
                val el = elements.getJSONObject(i)
                val tags = el.optJSONObject("tags") ?: continue
                val limit = parseMaxspeed(tags.optString("maxspeed")) ?: continue
                val geom = el.optJSONArray("geometry") ?: continue
                var nearest = Double.MAX_VALUE
                var roadBearing = 0f
                for (j in 0 until geom.length() - 1) {
                    val a = geom.getJSONObject(j)
                    val b = geom.getJSONObject(j + 1)
                    val alat = a.getDouble("lat")
                    val alon = a.getDouble("lon")
                    val blat = b.getDouble("lat")
                    val blon = b.getDouble("lon")
                    val d = distanceToSegment(lat, lon, alat, alon, blat, blon)
                    if (d < nearest) {
                        nearest = d
                        roadBearing = Geo.bearing(alat, alon, blat, blon)
                    }
                }
                // Prefer the road running the same way you are driving
                var score = nearest
                if (bearing != null) {
                    var diff = abs(((roadBearing - bearing) % 360f + 540f) % 360f - 180f).toDouble() // 0..180
                    if (tags.optString("oneway") != "yes") diff = min(diff, 180.0 - diff)
                    score += diff * 0.5
                }
                if (score < bestScore) {
                    bestScore = score
                    best = limit
                }
            }
            return best
        } finally {
            conn.disconnect()
        }
    }

    /** "100", "100 km/h", "60 mph" -> km/h; "none", "signals" -> null */
    private fun parseMaxspeed(raw: String): Int? {
        val n = Regex("(\\d+)").find(raw)?.value?.toIntOrNull() ?: return null
        return if (raw.contains("mph")) (n * 1.609).toInt() else n
    }

    /** Distance in metres from a point to a short road segment (flat-earth approximation). */
    private fun distanceToSegment(
        plat: Double, plon: Double,
        alat: Double, alon: Double,
        blat: Double, blon: Double
    ): Double {
        val kx = 111_320.0 * cos(Math.toRadians(plat))
        val ky = 110_540.0
        val ax = (alon - plon) * kx
        val ay = (alat - plat) * ky
        val bx = (blon - plon) * kx
        val by = (blat - plat) * ky
        val dx = bx - ax
        val dy = by - ay
        val len2 = dx * dx + dy * dy
        val t = if (len2 == 0.0) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
        val cx = ax + t * dx
        val cy = ay + t * dy
        return sqrt(cx * cx + cy * cy)
    }
}
