package com.example.offlinepoints

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream

/**
 * Reads points from a GPX file.
 * Waypoints (<wpt>) are imported. If the file has no waypoints at all,
 * route and track points (<rtept>, <trkpt>) are imported instead.
 */
object GpxParser {

    fun parse(input: InputStream, folder: String): List<GpxPoint> {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(input, null)

        val waypoints = ArrayList<GpxPoint>()
        val otherPoints = ArrayList<GpxPoint>()

        var pointTag: String? = null   // "wpt", "rtept" or "trkpt" while inside one
        var lat = 0.0
        var lon = 0.0
        var name = ""
        var desc = ""
        var ele: Double? = null
        var currentTag = ""

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    currentTag = localName(parser.name)
                    if (currentTag == "wpt" || currentTag == "rtept" || currentTag == "trkpt") {
                        val la = parser.getAttributeValue(null, "lat")?.trim()?.toDoubleOrNull()
                        val lo = parser.getAttributeValue(null, "lon")?.trim()?.toDoubleOrNull()
                        if (la != null && lo != null) {
                            pointTag = currentTag
                            lat = la
                            lon = lo
                            name = ""
                            desc = ""
                            ele = null
                        }
                    }
                }

                XmlPullParser.TEXT -> {
                    if (pointTag != null) {
                        val text = parser.text?.trim().orEmpty()
                        if (text.isNotEmpty()) {
                            when (currentTag) {
                                "name" -> name = text
                                "desc", "cmt" -> if (desc.isEmpty()) desc = text
                                "ele" -> ele = text.toDoubleOrNull()
                            }
                        }
                    }
                }

                XmlPullParser.END_TAG -> {
                    val tag = localName(parser.name)
                    if (pointTag != null && tag == pointTag) {
                        val p = GpxPoint(lat, lon, name, desc, ele, folder)
                        if (tag == "wpt") waypoints.add(p) else otherPoints.add(p)
                        pointTag = null
                    }
                    currentTag = ""
                }
            }
            event = parser.next()
        }

        return if (waypoints.isNotEmpty()) waypoints else otherPoints
    }

    /** "gpx:wpt" -> "wpt" */
    private fun localName(name: String): String = name.substringAfter(':').lowercase()
}
