package com.example.offlinepoints

import java.io.OutputStream
import java.util.Locale

/** Writes points as a standard GPX 1.1 file that Locus and other apps can open. */
object GpxWriter {

    fun write(out: OutputStream, folder: String, points: List<GpxPoint>) {
        val w = out.bufferedWriter(Charsets.UTF_8)
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        w.write("<gpx version=\"1.1\" creator=\"Mawqie\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        w.write("  <metadata><name>${esc(folder)}</name></metadata>\n")
        for (p in points) {
            w.write(String.format(Locale.US, "  <wpt lat=\"%.7f\" lon=\"%.7f\">\n", p.lat, p.lon))
            p.ele?.let { w.write(String.format(Locale.US, "    <ele>%.2f</ele>\n", it)) }
            if (p.created > 0) w.write("    <time>${Geo.isoTime(p.created)}</time>\n")
            if (p.name.isNotEmpty()) w.write("    <name>${esc(p.name)}</name>\n")
            if (p.desc.isNotEmpty()) w.write("    <desc>${esc(p.desc)}</desc>\n")
            w.write("  </wpt>\n")
        }
        w.write("</gpx>\n")
        w.flush()
    }

    private fun esc(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
