package com.example.offlinepoints

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.ITileSource
import java.io.File
import java.util.Locale

/** One map the user can choose: built in (Esri, OpenStreetMap) or loaded from a map file. */
class MapEntry(
    val key: String,
    val group: String,
    val title: String,
    val cacheName: String,
    val headers: Map<String, String>,
    val zoomMin: Int,
    val zoomMax: Int,
    val attribution: String,
    val isCustom: Boolean,
    val source: () -> ITileSource
) {
    val fullTitle: String get() = "$group $title"
}

/** All maps, plus per-map settings: hidden from the quick menu, and cache timeout. */
object MapRegistry {

    private const val PREFS = "mawqie"

    private val builtIns: List<MapEntry> by lazy {
        listOf(
            builtIn("esri_street", "Esri", "Street map", TileSources.STREET),
            builtIn("esri_sat", "Esri", "Satellite", TileSources.SATELLITE),
            builtIn("osm", "OpenStreetMap", "Classic", TileSources.OSM)
        )
    }

    private fun builtIn(key: String, group: String, title: String, src: ITileSource) = MapEntry(
        key = key,
        group = group,
        title = title,
        cacheName = src.name(),
        headers = emptyMap(),
        zoomMin = src.minimumZoomLevel,
        zoomMax = src.maximumZoomLevel,
        attribution = src.copyrightNotice ?: "",
        isCustom = false,
        source = { src }
    )

    fun all(ctx: Context): List<MapEntry> = builtIns + CustomMaps.load(ctx).map { c ->
        MapEntry(
            key = "custom:" + c.id,
            group = c.group,
            title = c.mode.ifBlank { c.name },
            cacheName = CustomMaps.cacheName(c),
            headers = c.headers,
            zoomMin = c.zoomMin,
            zoomMax = c.zoomMax,
            attribution = c.attribution,
            isCustom = true,
            source = { CustomMaps.tileSource(c) }
        )
    }

    fun find(ctx: Context, key: String): MapEntry? = all(ctx).firstOrNull { it.key == key }

    // ── Hidden from the quick map menu ───────────────────────────────────────

    fun isHidden(ctx: Context, key: String): Boolean =
        prefs(ctx).getStringSet("hiddenMaps", emptySet())?.contains(key) == true

    fun setHidden(ctx: Context, key: String, hidden: Boolean) {
        val set = HashSet(prefs(ctx).getStringSet("hiddenMaps", emptySet()) ?: emptySet())
        if (hidden) set.add(key) else set.remove(key)
        prefs(ctx).edit().putStringSet("hiddenMaps", set).apply()
    }

    // ── Cache timeout ────────────────────────────────────────────────────────

    private const val DAY = 24L * 60 * 60 * 1000

    /** Label and how long a downloaded tile is kept before it is refreshed (null = what the server says). */
    val timeouts: List<Pair<String, Long?>> = listOf(
        "Unlimited" to 100L * 365 * DAY,
        "1 day" to DAY,
        "1 week" to 7 * DAY,
        "1 month" to 30 * DAY,
        "6 months" to 182 * DAY,
        "Server default" to null
    )

    fun timeoutIndex(ctx: Context, key: String): Int =
        prefs(ctx).getInt("timeout_$key", 0).coerceIn(0, timeouts.size - 1)

    fun setTimeoutIndex(ctx: Context, key: String, index: Int) {
        prefs(ctx).edit().putInt("timeout_$key", index).apply()
    }

    fun timeoutLabel(ctx: Context, key: String): String = timeouts[timeoutIndex(ctx, key)].first

    fun timeoutMs(ctx: Context, key: String): Long? = timeouts[timeoutIndex(ctx, key)].second

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}

/** Reads and clears the map-tile cache (a small database the map engine keeps on the phone). */
object TileCache {

    class Stat(val tiles: Long, val bytes: Long)

    private fun dbFile(): File = File(Configuration.getInstance().osmdroidTileCache, "cache.db")

    private inline fun <T> withDb(fallback: T, block: (SQLiteDatabase) -> T): T {
        val f = dbFile()
        if (!f.exists()) return fallback
        return try {
            val db = SQLiteDatabase.openDatabase(f.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
            try {
                block(db)
            } finally {
                db.close()
            }
        } catch (e: Exception) {
            fallback
        }
    }

    /** Map cache name -> number of tiles and their size. */
    fun stats(): Map<String, Stat> = withDb(emptyMap()) { db ->
        val out = HashMap<String, Stat>()
        db.rawQuery("SELECT provider, COUNT(*), SUM(LENGTH(tile)) FROM tiles GROUP BY provider", null).use { c ->
            while (c.moveToNext()) out[c.getString(0)] = Stat(c.getLong(1), c.getLong(2))
        }
        out
    }

    /** Clears one map's tiles, or every map's tiles when [cacheName] is null. */
    fun clear(cacheName: String?) {
        withDb(Unit) { db ->
            if (cacheName == null) db.delete("tiles", null, null)
            else db.delete("tiles", "provider = ?", arrayOf(cacheName))
            try {
                db.execSQL("VACUUM") // give the space back to the phone
            } catch (e: Exception) {
                // the map may be using the cache right now; space is reused later anyway
            }
        }
    }

    fun formatBytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024))
        else -> String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024 * 1024))
    }
}
