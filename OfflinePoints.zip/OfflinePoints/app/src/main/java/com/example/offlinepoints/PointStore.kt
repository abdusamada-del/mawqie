package com.example.offlinepoints

import android.content.Context
import android.location.Location
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Saves all points in a JSON file inside the app's private storage,
 * so they stay on the phone and work without internet.
 */
object PointStore {

    private const val FILE_NAME = "points.json"
    private var cache: List<GpxPoint>? = null

    @Synchronized
    fun all(ctx: Context): List<GpxPoint> {
        cache?.let { return it }
        val file = File(ctx.filesDir, FILE_NAME)
        val list = ArrayList<GpxPoint>()
        if (file.exists()) {
            try {
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        GpxPoint(
                            lat = o.getDouble("lat"),
                            lon = o.getDouble("lon"),
                            name = o.optString("name", ""),
                            desc = o.optString("desc", ""),
                            ele = if (o.has("ele")) o.getDouble("ele") else null,
                            folder = o.optString("folder", "Imported")
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("PointStore", "Could not read saved points", e)
            }
        }
        cache = list
        return list
    }

    /** Puts [points] into [folder]. Points already in a folder with that name are replaced. */
    @Synchronized
    fun replaceFolder(ctx: Context, folder: String, points: List<GpxPoint>) {
        save(ctx, all(ctx).filter { it.folder != folder } + points)
    }

    @Synchronized
    fun deleteFolder(ctx: Context, folder: String) {
        save(ctx, all(ctx).filter { it.folder != folder })
    }

    /** Folder names with how many points each holds, sorted A-Z. */
    fun folders(ctx: Context): List<Pair<String, Int>> =
        all(ctx).groupingBy { it.folder }.eachCount().toList().sortedBy { it.first.lowercase() }

    /**
     * Finds points whose name (and optionally description) contains [query].
     * Results are sorted by distance from the given center, nearest first.
     */
    fun search(
        ctx: Context,
        query: String,
        inDescription: Boolean,
        folder: String?,
        centerLat: Double,
        centerLon: Double,
        limit: Int = 300
    ): List<Pair<GpxPoint, Float>> {
        val q = query.trim().lowercase()
        val result = FloatArray(1)
        return all(ctx).asSequence()
            .filter { folder == null || it.folder == folder }
            .filter {
                q.isEmpty() ||
                    it.name.lowercase().contains(q) ||
                    (inDescription && it.desc.lowercase().contains(q))
            }
            .map { p ->
                Location.distanceBetween(centerLat, centerLon, p.lat, p.lon, result)
                p to result[0]
            }
            .sortedBy { it.second }
            .take(limit)
            .toList()
    }

    private fun save(ctx: Context, list: List<GpxPoint>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("lat", p.lat)
            o.put("lon", p.lon)
            o.put("name", p.name)
            o.put("desc", p.desc)
            p.ele?.let { o.put("ele", it) }
            o.put("folder", p.folder)
            arr.put(o)
        }
        val tmp = File(ctx.filesDir, "$FILE_NAME.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(File(ctx.filesDir, FILE_NAME))
        cache = list
    }
}
