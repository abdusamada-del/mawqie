package com.example.offlinepoints

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** "My points" screen: list of folders. Tap one to show only that folder on the map. */
class LibraryActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_FOLDER = "folder"
    }

    private lateinit var adapter: FolderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))
        supportActionBar?.title = "My points"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        findViewById<View>(R.id.btnShowAll).setOnClickListener {
            setResult(RESULT_OK, Intent()) // no folder = show all
            finish()
        }

        adapter = FolderAdapter(
            onOpen = { folder ->
                setResult(RESULT_OK, Intent().putExtra(EXTRA_FOLDER, folder))
                finish()
            },
            onDelete = { folder, count -> confirmDelete(folder, count) }
        )

        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@LibraryActivity)
            adapter = this@LibraryActivity.adapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }

        refresh()
    }

    private fun refresh() {
        val folders = PointStore.folders(this)
        adapter.submit(folders)
        supportActionBar?.subtitle = "${folders.sumOf { it.second }} points in ${folders.size} folders"
        findViewById<View>(R.id.tvEmpty).visibility = if (folders.isEmpty()) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnShowAll).visibility = if (folders.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun confirmDelete(folder: String, count: Int) {
        AlertDialog.Builder(this)
            .setTitle("Delete \"$folder\"?")
            .setMessage("This removes its $count points from the app. The original GPX file is not touched.")
            .setPositiveButton("Delete") { _, _ ->
                PointStore.deleteFolder(this, folder)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}

class FolderAdapter(
    private val onOpen: (String) -> Unit,
    private val onDelete: (String, Int) -> Unit
) : RecyclerView.Adapter<FolderAdapter.Holder>() {

    private var items: List<Pair<String, Int>> = emptyList()

    fun submit(list: List<Pair<String, Int>>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val (name, count) = items[position]
        holder.tvName.text = name
        holder.tvCount.text = if (count == 1) "1 point" else "$count points"
        holder.itemView.setOnClickListener { onOpen(name) }
        holder.btnDelete.setOnClickListener { onDelete(name, count) }
    }

    override fun getItemCount(): Int = items.size

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tvFolderName)
        val tvCount: TextView = v.findViewById(R.id.tvFolderCount)
        val btnDelete: View = v.findViewById(R.id.btnDelete)
    }
}
