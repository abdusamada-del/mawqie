package com.example.offlinepoints

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "My points": groups and folders. */
class LibraryActivity : AppCompatActivity() {

    private lateinit var adapter: LibraryAdapter
    private val prefs by lazy { getSharedPreferences("mawqie", MODE_PRIVATE) }
    private var importTarget: String? = null
    private var exportTarget: String? = null

    private val importGpx =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val f = importTarget
            if (uri != null && f != null) doImport(uri, f)
        }

    private val exportGpx =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/gpx+xml")) { uri ->
            val f = exportTarget
            if (uri != null && f != null) doExport(uri, f)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)
        Repo.init(this)

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))
        supportActionBar?.title = "My points"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        adapter = LibraryAdapter(
            onGroup = { toggleGroup(it) },
            onFolder = { f ->
                startActivity(Intent(this, FolderActivity::class.java).putExtra(FolderActivity.EXTRA_FOLDER, f.name))
            },
            onMore = { f, anchor -> showFolderMenu(f, anchor) }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@LibraryActivity)
            adapter = this@LibraryActivity.adapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun expandedGroups(): MutableSet<String> =
        HashSet(prefs.getStringSet("expanded", emptySet()) ?: emptySet())

    private fun toggleGroup(name: String) {
        val set = expandedGroups()
        if (!set.add(name)) set.remove(name)
        prefs.edit().putStringSet("expanded", set).apply()
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            val folders = withContext(Dispatchers.IO) { Repo.folders() }
            val expanded = expandedGroups()
            val rows = ArrayList<LibRow>()
            folders.filter { it.group == null }.forEach { rows.add(LibRow.Folder(it, false)) }
            folders.filter { it.group != null }
                .groupBy { it.group!! }
                .toSortedMap(NaturalOrder)
                .forEach { (group, list) ->
                    val open = expanded.contains(group)
                    rows.add(LibRow.Group(group, list.size, open))
                    if (open) list.forEach { rows.add(LibRow.Folder(it, true)) }
                }
            adapter.rows = rows
            adapter.notifyDataSetChanged()
            supportActionBar?.subtitle = "${folders.sumOf { it.total }} points in ${folders.size} folders"
            findViewById<View>(R.id.tvEmpty).visibility = if (folders.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun showFolderMenu(f: FolderInfo, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Edit")
        pm.menu.add(0, 2, 1, "Import into this folder")
        pm.menu.add(0, 3, 2, "Export to GPX")
        pm.menu.add(0, 4, 3, "Delete")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> Dialogs.editFolder(this, f) { refresh() }
                2 -> {
                    importTarget = f.name
                    importGpx.launch(arrayOf("*/*"))
                }
                3 -> {
                    exportTarget = f.name
                    exportGpx.launch("${f.name}.gpx")
                }
                4 -> confirmDelete(f)
            }
            true
        }
        pm.show()
    }

    private fun confirmDelete(f: FolderInfo) {
        AlertDialog.Builder(this)
            .setTitle("Delete \"${f.name}\"?")
            .setMessage("This removes its ${f.total} points from the app. Your GPX files are not touched.")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { Repo.deleteFolder(f.name) }
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doImport(uri: Uri, folder: String) {
        Dialogs.runWithProgress(this, "Importing…", { report ->
            val pts = contentResolver.openInputStream(uri)?.use { GpxParser.parse(it, folder) }
                ?: error("Cannot open the file")
            if (pts.isNotEmpty()) Repo.addPoints(folder, pts, replace = false, progress = report)
            pts.size
        }) { result ->
            result.onSuccess { n ->
                toast(if (n == 0) "No points found in this file" else "Added $n points to \"$folder\"")
            }.onFailure { toast("Import failed: ${it.message}") }
            refresh()
        }
    }

    private fun doExport(uri: Uri, folder: String) {
        Dialogs.runWithProgress(this, "Exporting…", { report ->
            val pts = Repo.folderPoints(folder)
            report(50)
            contentResolver.openOutputStream(uri)?.use { GpxWriter.write(it, folder, pts) }
                ?: error("Cannot write the file")
            report(100)
            pts.size
        }) { result ->
            result.onSuccess { n -> toast("Exported $n points") }
                .onFailure { toast("Export failed: ${it.message}") }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}

sealed class LibRow {
    class Group(val name: String, val folderCount: Int, val expanded: Boolean) : LibRow()
    class Folder(val info: FolderInfo, val indented: Boolean) : LibRow()
}

class LibraryAdapter(
    private val onGroup: (String) -> Unit,
    private val onFolder: (FolderInfo) -> Unit,
    private val onMore: (FolderInfo, View) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var rows: List<LibRow> = emptyList()

    override fun getItemViewType(position: Int): Int = if (rows[position] is LibRow.Group) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout = if (viewType == 0) R.layout.item_group else R.layout.item_folder
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return object : RecyclerView.ViewHolder(v) {}
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val v = holder.itemView
        when (val r = rows[position]) {
            is LibRow.Group -> {
                v.findViewById<TextView>(R.id.tvGroupName).text = r.name
                v.findViewById<TextView>(R.id.tvGroupCount).text = "Folders: ${r.folderCount}"
                v.findViewById<ImageView>(R.id.ivExpand)
                    .setImageResource(if (r.expanded) R.drawable.ic_expand_less else R.drawable.ic_expand_more)
                v.setOnClickListener { onGroup(r.name) }
            }
            is LibRow.Folder -> {
                val f = r.info
                val ctx = v.context
                v.findViewById<ImageView>(R.id.ivFolderIcon)
                    .setImageBitmap(IconRegistry.bitmap(f.icon, IconRegistry.listSizePx(ctx, f.icon)))
                v.findViewById<TextView>(R.id.tvFolderName).text = f.name
                v.findViewById<TextView>(R.id.tvFolderCount).text = "${f.visibleCount} / ${f.total}"
                v.setPaddingRelative(
                    Dialogs.dp(ctx, if (r.indented) 40 else 16), v.paddingTop, v.paddingEnd, v.paddingBottom
                )
                v.setOnClickListener { onFolder(f) }
                v.findViewById<View>(R.id.btnMore).setOnClickListener { onMore(f, it) }
            }
        }
    }

    override fun getItemCount(): Int = rows.size
}
