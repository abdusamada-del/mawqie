package com.example.offlinepoints

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.core.graphics.PathParser
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Point icons. An icon id looks like:
 *   "m:dot:red"        a marker shape in a colour
 *   "s:bolt:utilities" a white symbol on a coloured square (colour comes from its section)
 */
object IconRegistry {

    const val DEFAULT = "m:dot:red"

    class Section(val title: String, val ids: List<String>)

    private val colors = linkedMapOf(
        "red" to 0xFFD50000.toInt(),
        "orange" to 0xFFFF6D00.toInt(),
        "yellow" to 0xFFFFD600.toInt(),
        "green" to 0xFF00C853.toInt(),
        "cyan" to 0xFF00B8D4.toInt(),
        "blue" to 0xFF2962FF.toInt(),
        "purple" to 0xFFAA00FF.toInt(),
        "black" to 0xFF212121.toInt(),
        "white" to 0xFFFFFFFF.toInt()
    )

    private val shapes = listOf("dot", "ring", "square", "diamond", "triangle", "cross", "plus", "pin")

    private val sectionColors = mapOf(
        "general" to 0xFF1565C0.toInt(),
        "utilities" to 0xFFE65100.toInt(),
        "transport" to 0xFF5D4037.toInt(),
        "nature" to 0xFF2E7D32.toInt()
    )

    private val symbolSections = listOf(
        "General" to listOf("home", "star", "flag", "info", "warning", "place", "heart", "check", "close", "lock"),
        "Utilities" to listOf("bolt", "power", "build", "settings", "water"),
        "Transport" to listOf("car", "truck", "bus", "flight", "parking"),
        "Nature" to listOf("park", "terrain", "water")
    )

    /** Material Design icon outlines (24 x 24). */
    private val symbols = mapOf(
        "home" to "M10,20v-6h4v6h5v-8h3L12,3 2,12h3v8z",
        "star" to "M12,17.27L18.18,21l-1.64,-7.03L22,9.24l-7.19,-0.61L12,2 9.19,8.63 2,9.24l5.46,4.73L5.82,21z",
        "flag" to "M14.4,6L14,4H5v17h2v-7h5.6l0.4,2h7V6z",
        "info" to "M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM13,17h-2v-6h2v6zM13,9h-2V7h2v2z",
        "warning" to "M1,21h22L12,2 1,21zM13,18h-2v-2h2v2zM13,14h-2v-4h2v4z",
        "place" to "M12,2C8.13,2 5,5.13 5,9c0,5.25 7,13 7,13s7,-7.75 7,-13c0,-3.87 -3.13,-7 -7,-7zM12,11.5c-1.38,0 -2.5,-1.12 -2.5,-2.5s1.12,-2.5 2.5,-2.5 2.5,1.12 2.5,2.5 -1.12,2.5 -2.5,2.5z",
        "heart" to "M12,21.35l-1.45,-1.32C5.4,15.36 2,12.28 2,8.5 2,5.42 4.42,3 7.5,3c1.74,0 3.41,0.81 4.5,2.09C13.09,3.81 14.76,3 16.5,3 19.58,3 22,5.42 22,8.5c0,3.78 -3.4,6.86 -8.55,11.54L12,21.35z",
        "check" to "M9,16.2L4.8,12l-1.4,1.4L9,19 21,7l-1.4,-1.4L9,16.2z",
        "close" to "M19,6.41L17.59,5 12,10.59 6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 12,13.41 17.59,19 19,17.59 13.41,12z",
        "lock" to "M18,8h-1V6c0,-2.76 -2.24,-5 -5,-5S7,3.24 7,6v2H6c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V10c0,-1.1 -0.9,-2 -2,-2zM12,17c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2 2,0.9 2,2 -0.9,2 -2,2zM15.1,8H8.9V6c0,-1.71 1.39,-3.1 3.1,-3.1 1.71,0 3.1,1.39 3.1,3.1v2z",
        "bolt" to "M7,2v11h3v9l7,-12h-4l4,-8z",
        "power" to "M13,3h-2v10h2V3zM17.83,5.17l-1.42,1.42C17.99,7.86 19,9.81 19,12c0,3.87 -3.13,7 -7,7s-7,-3.13 -7,-7c0,-2.19 1.01,-4.14 2.58,-5.42L6.17,5.17C4.23,6.82 3,9.26 3,12c0,4.97 4.03,9 9,9s9,-4.03 9,-9c0,-2.74 -1.23,-5.18 -3.17,-6.83z",
        "build" to "M22.7,19l-9.1,-9.1c0.9,-2.3 0.4,-5 -1.5,-6.9 -2,-2 -5,-2.4 -7.4,-1.3L9,6 6,9 1.6,4.7C0.4,7.1 0.9,10.1 2.9,12.1c1.9,1.9 4.6,2.4 6.9,1.5l9.1,9.1c0.4,0.4 1,0.4 1.4,0l2.3,-2.3c0.5,-0.4 0.5,-1.1 0.1,-1.4z",
        "settings" to "M19.14,12.94c0.04,-0.3 0.06,-0.61 0.06,-0.94 0,-0.32 -0.02,-0.64 -0.07,-0.94l2.03,-1.58c0.18,-0.14 0.23,-0.41 0.12,-0.61l-1.92,-3.32c-0.12,-0.22 -0.37,-0.29 -0.59,-0.22l-2.39,0.96c-0.5,-0.38 -1.03,-0.7 -1.62,-0.94L14.4,2.81c-0.04,-0.24 -0.24,-0.41 -0.48,-0.41h-3.84c-0.24,0 -0.43,0.17 -0.47,0.41L9.25,5.35C8.66,5.59 8.12,5.92 7.63,6.29L5.24,5.33c-0.22,-0.08 -0.47,0 -0.59,0.22L2.74,8.87C2.62,9.08 2.66,9.34 2.86,9.48l2.03,1.58C4.84,11.36 4.8,11.69 4.8,12s0.02,0.64 0.07,0.94l-2.03,1.58c-0.18,0.14 -0.23,0.41 -0.12,0.61l1.92,3.32c0.12,0.22 0.37,0.29 0.59,0.22l2.39,-0.96c0.5,0.38 1.03,0.7 1.62,0.94l0.36,2.54c0.05,0.24 0.24,0.41 0.48,0.41h3.84c0.24,0 0.44,-0.17 0.47,-0.41l0.36,-2.54c0.59,-0.24 1.13,-0.56 1.62,-0.94l2.39,0.96c0.22,0.08 0.47,0 0.59,-0.22l1.92,-3.32c0.12,-0.22 0.07,-0.47 -0.12,-0.61L19.14,12.94zM12,15.6c-1.98,0 -3.6,-1.62 -3.6,-3.6s1.62,-3.6 3.6,-3.6 3.6,1.62 3.6,3.6S13.98,15.6 12,15.6z",
        "water" to "M12,2.69l5.66,5.66a8,8 0,1 1,-11.31 0z",
        "car" to "M18.92,6.01C18.72,5.42 18.16,5 17.5,5h-11c-0.66,0 -1.21,0.42 -1.42,1.01L3,12v8c0,0.55 0.45,1 1,1h1c0.55,0 1,-0.45 1,-1v-1h12v1c0,0.55 0.45,1 1,1h1c0.55,0 1,-0.45 1,-1v-8l-2.08,-5.99zM6.5,16c-0.83,0 -1.5,-0.67 -1.5,-1.5S5.67,13 6.5,13s1.5,0.67 1.5,1.5S7.33,16 6.5,16zM17.5,16c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5zM5,11l1.5,-4.5h11L19,11H5z",
        "truck" to "M20,8h-3V4H3c-1.1,0 -2,0.9 -2,2v11h2c0,1.66 1.34,3 3,3s3,-1.34 3,-3h6c0,1.66 1.34,3 3,3s3,-1.34 3,-3h2v-5l-3,-4zM6,18.5c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5zM19.5,9.5l1.96,2.5H17V9.5h2.5zM18,18.5c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5z",
        "bus" to "M4,16c0,0.88 0.39,1.67 1,2.22V20c0,0.55 0.45,1 1,1h1c0.55,0 1,-0.45 1,-1v-1h8v1c0,0.55 0.45,1 1,1h1c0.55,0 1,-0.45 1,-1v-1.78c0.61,-0.55 1,-1.34 1,-2.22V6c0,-3.5 -3.58,-4 -8,-4s-8,0.5 -8,4v10zM7.5,17c-0.83,0 -1.5,-0.67 -1.5,-1.5S6.67,14 7.5,14s1.5,0.67 1.5,1.5S8.33,17 7.5,17zM16.5,17c-0.83,0 -1.5,-0.67 -1.5,-1.5s0.67,-1.5 1.5,-1.5 1.5,0.67 1.5,1.5 -0.67,1.5 -1.5,1.5zM18,11H6V6h12v5z",
        "flight" to "M21,16v-2l-8,-5V3.5c0,-0.83 -0.67,-1.5 -1.5,-1.5S10,2.67 10,3.5V9l-8,5v2l8,-2.5V19l-2,1.5V22l3.5,-1 3.5,1v-1.5L13,19v-5.5l8,2.5z",
        "parking" to "M13,3H6v18h4v-6h3c3.31,0 6,-2.69 6,-6s-2.69,-6 -6,-6zM13.2,11H10V7h3.2c1.1,0 2,0.9 2,2s-0.9,2 -2,2z",
        "park" to "M17,12h2L12,2 5.05,12H7l-3.9,6h6.92v4h3.95v-4H21z",
        "terrain" to "M14,6l-3.75,5 2.85,3.8 -1.6,1.2C9.81,13.75 7,10 7,10l-6,8h22L14,6z"
    )

    val sections: List<Section> by lazy {
        val list = ArrayList<Section>()
        list.add(Section("Markers", shapes.flatMap { s -> colors.keys.map { c -> "m:$s:$c" } }))
        for ((title, names) in symbolSections) {
            list.add(Section(title, names.map { "s:$it:${title.lowercase()}" }))
        }
        list
    }

    fun isMarker(id: String) = id.startsWith("m:")

    /** Size of the icon in dp at size 1.0. */
    fun baseSizeDp(id: String): Float = if (isMarker(id)) 7f else 20f

    /** Size used in lists (folder rows, point rows). */
    fun listSizePx(ctx: Context, id: String): Int {
        val d = ctx.resources.displayMetrics.density
        return ((if (isMarker(id)) 14f else 24f) * d).roundToInt()
    }

    private val cache = HashMap<String, Bitmap>()

    @Synchronized
    fun bitmap(id: String, sizePx: Int): Bitmap {
        val s = sizePx.coerceAtLeast(4)
        val key = "$id@$s"
        cache[key]?.let { return it }
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        try {
            draw(Canvas(bmp), id, s.toFloat())
        } catch (e: Exception) {
            bmp.eraseColor(Color.TRANSPARENT)
            draw(Canvas(bmp), DEFAULT, s.toFloat())
        }
        if (cache.size > 400) cache.clear()
        cache[key] = bmp
        return bmp
    }

    private fun draw(c: Canvas, id: String, s: Float) {
        val parts = id.split(":")
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xDD000000.toInt()
        }

        if (parts[0] == "m") {
            fill.color = colors[parts.getOrElse(2) { "red" }] ?: colors.getValue("red")
            outline.strokeWidth = max(1f, s * 0.12f)
            val m = outline.strokeWidth
            val cx = s / 2
            val cy = s / 2
            val r = s / 2 - m
            when (parts.getOrElse(1) { "dot" }) {
                "ring" -> {
                    val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        color = fill.color
                        strokeWidth = s * 0.24f
                    }
                    val rr = s / 2 - ring.strokeWidth / 2 - m / 2
                    c.drawCircle(cx, cy, s / 2 - m / 2, outline)
                    c.drawCircle(cx, cy, rr, ring)
                    c.drawCircle(cx, cy, rr - ring.strokeWidth / 2, outline)
                }
                "square" -> {
                    val rect = RectF(m, m, s - m, s - m)
                    c.drawRect(rect, fill)
                    c.drawRect(rect, outline)
                }
                "diamond" -> {
                    val p = Path().apply {
                        moveTo(cx, m); lineTo(s - m, cy); lineTo(cx, s - m); lineTo(m, cy); close()
                    }
                    c.drawPath(p, fill)
                    c.drawPath(p, outline)
                }
                "triangle" -> {
                    val p = Path().apply {
                        moveTo(m, m * 1.5f); lineTo(s - m, m * 1.5f); lineTo(cx, s - m); close()
                    }
                    c.drawPath(p, fill)
                    c.drawPath(p, outline)
                }
                "cross", "plus" -> {
                    val back = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        color = outline.color
                        strokeWidth = s * 0.34f
                        strokeCap = Paint.Cap.ROUND
                    }
                    val front = Paint(back).apply {
                        color = fill.color
                        strokeWidth = s * 0.18f
                    }
                    val a = s * 0.22f
                    val b = s - a
                    val lines = if (parts[1] == "cross") {
                        floatArrayOf(a, a, b, b, a, b, b, a)
                    } else {
                        floatArrayOf(cx, a, cx, b, a, cy, b, cy)
                    }
                    c.drawLines(lines, back)
                    c.drawLines(lines, front)
                }
                "pin" -> {
                    val head = s * 0.32f
                    val p = Path().apply {
                        addCircle(cx, m + head, head, Path.Direction.CW)
                        moveTo(cx - head * 0.75f, m + head * 1.6f)
                        lineTo(cx, s - m)
                        lineTo(cx + head * 0.75f, m + head * 1.6f)
                        close()
                    }
                    c.drawPath(p, fill)
                    c.drawCircle(cx, m + head, head, outline)
                    c.drawCircle(cx, m + head, head * 0.35f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
                }
                else -> { // dot
                    c.drawCircle(cx, cy, r, fill)
                    c.drawCircle(cx, cy, r, outline)
                }
            }
        } else {
            fill.color = sectionColors[parts.getOrElse(2) { "general" }] ?: sectionColors.getValue("general")
            val m = s * 0.05f
            val rect = RectF(m, m, s - m, s - m)
            c.drawRoundRect(rect, s * 0.2f, s * 0.2f, fill)
            outline.color = Color.WHITE
            outline.strokeWidth = max(1f, s * 0.06f)
            c.drawRoundRect(rect, s * 0.2f, s * 0.2f, outline)
            val path = PathParser.createPathFromPathData(symbols.getValue(parts[1]))
            val inner = s * 0.64f
            val off = (s - inner) / 2
            val mtx = Matrix()
            mtx.setScale(inner / 24f, inner / 24f)
            mtx.postTranslate(off, off)
            path.transform(mtx)
            c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        }
    }
}
