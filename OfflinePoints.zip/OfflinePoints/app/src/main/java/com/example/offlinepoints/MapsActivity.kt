package com.example.offlinepoints

import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "Maps" screen, like Locus: choose a map, see its cache, clear it, set cache timeout, hide or delete. */
class MapsActivity : AppCompatActivity() {

    private lateinit var adapter: MapsAdapter
    private lateinit var btnClearAll: TextView
    private val prefs by lazy { getSharedPreferences("mawqie", MODE_PRIVATE) }
    private var stats: Map<String, TileCache.Stat> = emptyMap()

    private val pickMapFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importMapFile(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))
        supportActionBar?.title = "Maps"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        adapter = MapsAdapter(
            onSelect = { e -> selectMap(e) },
            onMore = { e, anchor -> showMapMenu(e, anchor) }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MapsActivity)
            adapter = this@MapsActivity.adapter
        }
        findViewById<View>(R.id.btnAddMaps).setOnClickListener { pickMapFile.launch(arrayOf("*/*")) }
        btnClearAll = findViewById(R.id.btnClearAll)
        btnClearAll.setOnClickListener { confirmClear(null, "all maps") }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun currentKey() = prefs.getString("mapSource", "esri_street") ?: "esri_street"

    private fun markChanged() = prefs.edit().putBoolean("mapsChanged", true).apply()

    private fun refresh() {
        lifecycleScope.launch {
            stats = withContext(Dispatchers.IO) { TileCache.stats() }
            val entries = MapRegistry.all(this@MapsActivity)
            val rows = ArrayList<Any>()
            var lastGroup: String? = null
            for (e in entries) {
                val section = if (e.isCustom) "User maps · ${e.group}" else e.group
                if (section != lastGroup) {
                    rows.add(section)
                    lastGroup = section
                }
                rows.add(e)
            }
            adapter.current = currentKey()
            adapter.stats = stats
            adapter.hidden = entries.filter { MapRegistry.isHidden(this@MapsActivity, it.key) }.map { it.key }.toSet()
            adapter.timeouts = entries.associate { it.key to MapRegistry.timeoutLabel(this@MapsActivity, it.key) }
            adapter.rows = rows
            adapter.notifyDataSetChanged()
            val total = stats.values.sumOf { it.bytes }
            btnClearAll.text = "Clear all cache\n${TileCache.formatBytes(total)}"
        }
    }

    private fun selectMap(e: MapEntry) {
        prefs.edit().putString("mapSource", e.key).apply()
        markChanged()
        finish()
    }

    private fun showMapMenu(e: MapEntry, anchor: View) {
        val hidden = MapRegistry.isHidden(this, e.key)
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Details")
        pm.menu.add(0, 2, 1, "Set cache timeout")
        pm.menu.add(0, 3, 2, "Clear map cache")
        pm.menu.add(0, 4, 3, if (hidden) "Show in map menu" else "Hide from map menu")
        if (e.isCustom) pm.menu.add(0, 5, 4, "Delete map")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> showDetails(e)
                2 -> chooseTimeout(e)
                3 -> confirmClear(e.cacheName, e.fullTitle)
                4 -> {
                    MapRegistry.setHidden(this, e.key, !hidden)
                    refresh()
                }
                5 -> confirmDelete(e)
            }
            true
        }
        pm.show()
    }

    private fun showDetails(e: MapEntry) {
        val st = stats[e.cacheName]
        val msg = buildString {
            append("Zooms: ${e.zoomMin} - ${e.zoomMax}\n")
            append("Cached tiles: ${st?.tiles ?: 0}\n")
            append("Cache: ${TileCache.formatBytes(st?.bytes ?: 0)}\n")
            append("Cache timeout: ${MapRegistry.timeoutLabel(this@MapsActivity, e.key)}\n")
            append("Shown in map menu: ${if (MapRegistry.isHidden(this@MapsActivity, e.key)) "No" else "Yes"}")
            if (e.attribution.isNotBlank()) append("\n\n${e.attribution}")
        }
        AlertDialog.Builder(this).setTitle(e.fullTitle).setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun chooseTimeout(e: MapEntry) {
        val labels = MapRegistry.timeouts.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Cache timeout: ${e.fullTitle}")
            .setSingleChoiceItems(labels, MapRegistry.timeoutIndex(this, e.key)) { d, which ->
                MapRegistry.setTimeoutIndex(this, e.key, which)
                if (e.key == currentKey()) markChanged()
                d.dismiss()
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmClear(cacheName: String?, what: String) {
        val bytes = if (cacheName == null) stats.values.sumOf { it.bytes } else stats[cacheName]?.bytes ?: 0
        AlertDialog.Builder(this)
            .setTitle("Clear map cache?")
            .setMessage("Removes ${TileCache.formatBytes(bytes)} of saved map pictures for $what. " +
                "They download again when you view those areas online. Your points are not touched.")
            .setPositiveButton("Clear") { _, _ ->
                Dialogs.runWithProgress(this, "Clearing…", { report ->
                    TileCache.clear(cacheName)
                    report(100)
                }) {
                    markChanged()
                    Toast.makeText(this, "Map cache cleared", Toast.LENGTH_SHORT).show()
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDelete(e: MapEntry) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${e.fullTitle}?")
            .setMessage("Removes this map and its saved map pictures. You can add it again from your map file.")
            .setPositiveButton("Delete") { _, _ ->
                CustomMaps.remove(this, e.key.removePrefix("custom:"))
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { TileCache.clear(e.cacheName) }
                    if (currentKey() == e.key) prefs.edit().putString("mapSource", "esri_street").apply()
                    markChanged()
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun importMapFile(uri: Uri) {
        Dialogs.runWithProgress(this, "Reading map file…", { report ->
            val maps = contentResolver.openInputStream(uri)?.use { CustomMaps.parse(it) }
                ?: error("Cannot open the file")
            report(100)
            maps
        }) { result ->
            result.onSuccess { maps ->
                if (maps.isEmpty()) {
                    Toast.makeText(this, "No maps found in this file", Toast.LENGTH_LONG).show()
                } else {
                    CustomMaps.add(this, maps)
                    Toast.makeText(this, "Added ${maps.size} maps", Toast.LENGTH_LONG).show()
                    refresh()
                }
            }.onFailure {
                Toast.makeText(this, "Could not read the map file: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}

/** Rows are either a section title (String) or a map (MapEntry). */
class MapsAdapter(
    private val onSelect: (MapEntry) -> Unit,
    private val onMore: (MapEntry, View) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var rows: List<Any> = emptyList()
    var current: String = ""
    var stats: Map<String, TileCache.Stat> = emptyMap()
    var hidden: Set<String> = emptySet()
    var timeouts: Map<String, String> = emptyMap()

    override fun getItemViewType(position: Int): Int = if (rows[position] is String) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val v: View = if (viewType == 0) {
            TextView(parent.context).apply {
                val d = parent.context.resources.displayMetrics.density
                setPadding((16 * d).toInt(), (18 * d).toInt(), (16 * d).toInt(), (6 * d).toInt())
                setTextColor(0xFF1E76D0.toInt())
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        } else {
            LayoutInflater.from(parent.context).inflate(R.layout.item_map, parent, false)
        }
        return object : RecyclerView.ViewHolder(v) {}
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        if (row is String) {
            (holder.itemView as TextView).text = row.uppercase()
            return
        }
        val e = row as MapEntry
        val v = holder.itemView
        val title = v.findViewById<TextView>(R.id.tvMapTitle)
        title.text = e.title
        title.setTextColor(if (e.key == current) 0xFF1E76D0.toInt() else 0xFF212121.toInt())
        val st = stats[e.cacheName]
        val parts = ArrayList<String>()
        parts.add("Cache ${TileCache.formatBytes(st?.bytes ?: 0)}")
        parts.add("Timeout ${timeouts[e.key] ?: "Unlimited"}")
        if (e.key in hidden) parts.add("Hidden")
        if (e.key == current) parts.add(0, "In use")
        v.findViewById<TextView>(R.id.tvMapInfo).text = parts.joinToString("  ·  ")
        v.alpha = if (e.key in hidden) 0.55f else 1f
        v.setOnClickListener { onSelect(e) }
        v.findViewById<View>(R.id.btnMapMore).setOnClickListener { onMore(e, it) }
    }

    override fun getItemCount(): Int = rows.size
}
