package com.example.offlinepoints

import java.util.Locale

/** One saved point. [folder] is the group it was imported into. */
data class GpxPoint(
    val lat: Double,
    val lon: Double,
    val name: String = "",
    val desc: String = "",
    val ele: Double? = null,
    val folder: String = "Imported"
) {
    val label: String
        get() = name.ifBlank { String.format(Locale.US, "%.5f, %.5f", lat, lon) }

    val coords: String
        get() = String.format(Locale.US, "%.6f, %.6f", lat, lon)
}
