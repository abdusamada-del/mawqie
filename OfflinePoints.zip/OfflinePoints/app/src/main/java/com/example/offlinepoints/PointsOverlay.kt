package com.example.offlinepoints

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import org.osmdroid.api.IGeoPoint
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** Draws a name label in a white box with a thin grey border, centred below a point (Locus style). */
class LabelPainter(private val density: Float) {

    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) // a touch bolder, like Locus
    }
    private val bg = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A8A8A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = density
    }

    /**
     * Returns false (and draws nothing) if [placed] is given and the label
     * would overlap a label already drawn.
     */
    fun draw(
        c: Canvas,
        line1: String,
        line2: String?,
        x: Float,
        iconBottom: Float,
        scale: Float,
        placed: MutableList<RectF>?
    ): Boolean {
        // Size 1.0 measured against Locus screenshots (label box about 51 x 141 px at 2.75x)
        text.textSize = 11.2f * density * scale
        val padH = 4f * density * scale
        val padV = 2.7f * density * scale
        val fm = text.fontMetrics
        val lineH = fm.descent - fm.ascent
        val w1 = text.measureText(line1)
        val w2 = if (line2 != null) text.measureText(line2) else 0f
        val bw = max(w1, w2) + 2 * padH
        val bh = lineH * (if (line2 != null) 2 else 1) + 2 * padV
        val top = iconBottom + 12f * density // gap between point and label, like Locus
        val rect = RectF(x - bw / 2, top, x + bw / 2, top + bh)
        if (placed != null) {
            for (o in placed) if (RectF.intersects(o, rect)) return false
            placed.add(rect)
        }
        c.drawRect(rect, bg)
        c.drawRect(rect, border)
        var baseline = top + padV - fm.ascent
        c.drawText(line1, x - w1 / 2, baseline, text)
        if (line2 != null) {
            baseline += lineH
            c.drawText(line2, x - w2 / 2, baseline, text)
        }
        return true
    }
}

/**
 * Draws all switched-on points with their folder's icon, size and label style.
 * When zoomed out, at most one point is drawn per small square of screen,
 * so tens of thousands of points stay fast and readable.
 */
class PointsOverlay(
    ctx: Context,
    private val onTap: (Long) -> Unit,
    private val myLocation: () -> IGeoPoint?
) : Overlay() {

    companion object {
        const val LABEL_MIN_ZOOM = 15.0
        private const val MAX_DRAWN = 8000
        private const val MAX_LABELS = 250
    }

    var points: List<MapPoint> = emptyList()
        private set
    var showAll = true
    var selected: MapPoint? = null

    private val density = ctx.resources.displayMetrics.density
    private val labels = LabelPainter(density)
    private var styles: Map<String, FolderInfo> = emptyMap()
    private var icons: Map<String, Bitmap> = emptyMap()
    private val defaultIcon: Bitmap = IconRegistry.bitmap(IconRegistry.DEFAULT, sizePx(IconRegistry.DEFAULT, 1f))

    private val drawnX = FloatArray(MAX_DRAWN)
    private val drawnY = FloatArray(MAX_DRAWN)
    private val drawnIdx = IntArray(MAX_DRAWN)
    private val screenX = FloatArray(MAX_DRAWN)
    private val screenY = FloatArray(MAX_DRAWN)
    private var drawnCount = 0

    private val gp = GeoPoint(0.0, 0.0)
    private val px = Point()
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1E76D0.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }

    fun sizePx(icon: String, scale: Float): Int =
        (IconRegistry.baseSizeDp(icon) * scale * density).roundToInt().coerceAtLeast(4)

    fun setData(points: List<MapPoint>, styles: Map<String, FolderInfo>, showAll: Boolean) {
        this.points = points
        this.styles = styles
        this.showAll = showAll
        icons = styles.mapValues { (_, f) -> IconRegistry.bitmap(f.icon, sizePx(f.icon, f.iconSize)) }
    }

    private fun iconFor(folder: String): Bitmap = icons[folder] ?: defaultIcon

    override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
        if (shadow) return
        drawnCount = 0
        val proj = mapView.projection
        val showLabels = mapView.zoomLevelDouble >= LABEL_MIN_ZOOM

        // When the map is rotated, the canvas is turned with it. We undo that turn and draw
        // icons and labels at their on-screen spots, so they always stay upright.
        val angle = mapView.mapOrientation
        val rotated = abs(angle % 360f) > 0.01f
        val cx = mapView.width / 2f
        val cy = mapView.height / 2f
        val rad = Math.toRadians(angle.toDouble())
        val cosA = cos(rad).toFloat()
        val sinA = sin(rad).toFloat()
        canvas.save()
        if (rotated) canvas.rotate(-angle, cx, cy)

        if (showAll && points.isNotEmpty()) {
            val bb = if (rotated) proj.boundingBox.increaseByScale(1.5f) else proj.boundingBox
            val north = bb.latNorth
            val south = bb.latSouth
            val east = bb.lonEast
            val west = bb.lonWest
            val cell = (6 * density).roundToInt().coerceAtLeast(4)
            val cols = mapView.width / cell + 3
            val rows = mapView.height / cell + 3
            val occupied = BooleanArray(cols * rows)

            for (i in points.indices) {
                val p = points[i]
                if (p.lat > north || p.lat < south) continue
                if (west <= east) {
                    if (p.lon < west || p.lon > east) continue
                } else if (p.lon < west && p.lon > east) continue

                gp.setCoords(p.lat, p.lon)
                proj.toPixels(gp, px)
                // on-screen position
                val dx = px.x - cx
                val dy = px.y - cy
                val sx = if (rotated) cx + dx * cosA - dy * sinA else px.x.toFloat()
                val sy = if (rotated) cy + dx * sinA + dy * cosA else px.y.toFloat()

                val gx = (sx / cell).toInt() + 1
                val gy = (sy / cell).toInt() + 1
                if (sx < -cell || sy < -cell || gx >= cols || gy >= rows) continue
                val k = gy * cols + gx
                if (occupied[k]) continue
                occupied[k] = true

                val bmp = iconFor(p.folder)
                canvas.drawBitmap(bmp, sx - bmp.width / 2f, sy - bmp.height / 2f, null)
                if (drawnCount < MAX_DRAWN) {
                    drawnX[drawnCount] = px.x.toFloat() // taps arrive in un-rotated map coordinates
                    drawnY[drawnCount] = px.y.toFloat()
                    screenX[drawnCount] = sx
                    screenY[drawnCount] = sy
                    drawnIdx[drawnCount] = i
                    drawnCount++
                }
            }

            if (showLabels) {
                val placed = ArrayList<RectF>()
                var count = 0
                for (d in 0 until drawnCount) {
                    if (count >= MAX_LABELS) break
                    val p = points[drawnIdx[d]]
                    val style = styles[p.folder]
                    if ((style?.labelMode ?: FolderInfo.LABEL_ALWAYS) != FolderInfo.LABEL_ALWAYS) continue
                    if (p.id == selected?.id) continue
                    val bmp = iconFor(p.folder)
                    if (labels.draw(canvas, p.label, null, screenX[d], screenY[d] + bmp.height / 2f, style?.labelSize ?: 1f, placed)) {
                        count++
                    }
                }
            }
        }

        // The selected point is always drawn, with its label and distance from you.
        selected?.let { s ->
            gp.setCoords(s.lat, s.lon)
            proj.toPixels(gp, px)
            val dx = px.x - cx
            val dy = px.y - cy
            val x = if (rotated) cx + dx * cosA - dy * sinA else px.x.toFloat()
            val y = if (rotated) cy + dx * sinA + dy * cosA else px.y.toFloat()
            val bmp = iconFor(s.folder)
            canvas.drawCircle(x, y, max(bmp.width, bmp.height) / 2f + 4 * density, ring)
            canvas.drawBitmap(bmp, x - bmp.width / 2f, y - bmp.height / 2f, null)
            val here = myLocation()
            val distance = here?.let {
                "Distance: " + Geo.formatDistance(Geo.distance(it.latitude, it.longitude, s.lat, s.lon))
            }
            labels.draw(canvas, s.label, distance, x, y + bmp.height / 2f, styles[s.folder]?.labelSize ?: 1f, null)
        }
        canvas.restore()
    }

    override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
        val r = 20 * density
        var best = -1
        var bestD = r * r
        for (d in 0 until drawnCount) {
            val dx = drawnX[d] - e.x
            val dy = drawnY[d] - e.y
            val dd = dx * dx + dy * dy
            if (dd < bestD) {
                bestD = dd
                best = d
            }
        }
        if (best < 0) return false
        val p = points[drawnIdx[best]]
        selected = p
        mapView.invalidate()
        onTap(p.id)
        return true
    }
}
