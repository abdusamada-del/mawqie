package com.example.offlinepoints

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RectF
import android.view.MotionEvent
import org.osmdroid.api.IGeoPoint
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import kotlin.math.max
import kotlin.math.roundToInt

/** Draws a name label in a white box with a thin grey border, centred below a point (Locus style). */
class LabelPainter(private val density: Float) {

    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val bg = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A8A8A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = density
    }

    /**
     * Returns false (and draws nothing) if [placed] is given and the label
     * would overlap a label already drawn.
     */
    fun draw(
        c: Canvas,
        line1: String,
        line2: String?,
        x: Float,
        iconBottom: Float,
        scale: Float,
        placed: MutableList<RectF>?
    ): Boolean {
        text.textSize = 13f * density * scale
        val padH = 5f * density * scale
        val padV = 3f * density * scale
        val fm = text.fontMetrics
        val lineH = fm.descent - fm.ascent
        val w1 = text.measureText(line1)
        val w2 = if (line2 != null) text.measureText(line2) else 0f
        val bw = max(w1, w2) + 2 * padH
        val bh = lineH * (if (line2 != null) 2 else 1) + 2 * padV
        val top = iconBottom + 13f * density // gap between point and label, like Locus
        val rect = RectF(x - bw / 2, top, x + bw / 2, top + bh)
        if (placed != null) {
            for (o in placed) if (RectF.intersects(o, rect)) return false
            placed.add(rect)
        }
        c.drawRect(rect, bg)
        c.drawRect(rect, border)
        var baseline = top + padV - fm.ascent
        c.drawText(line1, x - w1 / 2, baseline, text)
        if (line2 != null) {
            baseline += lineH
            c.drawText(line2, x - w2 / 2, baseline, text)
        }
        return true
    }
}

/**
 * Draws all switched-on points with their folder's icon, size and label style.
 * When zoomed out, at most one point is drawn per small square of screen,
 * so tens of thousands of points stay fast and readable.
 */
class PointsOverlay(
    ctx: Context,
    private val onTap: (Long) -> Unit,
    private val myLocation: () -> IGeoPoint?
) : Overlay() {

    companion object {
        const val LABEL_MIN_ZOOM = 15.0
        private const val MAX_DRAWN = 8000
        private const val MAX_LABELS = 250
    }

    var points: List<MapPoint> = emptyList()
        private set
    var showAll = true
    var selected: MapPoint? = null

    private val density = ctx.resources.displayMetrics.density
    private val labels = LabelPainter(density)
    private var styles: Map<String, FolderInfo> = emptyMap()
    private var icons: Map<String, Bitmap> = emptyMap()
    private val defaultIcon: Bitmap = IconRegistry.bitmap(IconRegistry.DEFAULT, sizePx(IconRegistry.DEFAULT, 1f))

    private val drawnX = FloatArray(MAX_DRAWN)
    private val drawnY = FloatArray(MAX_DRAWN)
    private val drawnIdx = IntArray(MAX_DRAWN)
    private var drawnCount = 0

    private val gp = GeoPoint(0.0, 0.0)
    private val px = Point()
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1E76D0.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }

    fun sizePx(icon: String, scale: Float): Int =
        (IconRegistry.baseSizeDp(icon) * scale * density).roundToInt().coerceAtLeast(4)

    fun setData(points: List<MapPoint>, styles: Map<String, FolderInfo>, showAll: Boolean) {
        this.points = points
        this.styles = styles
        this.showAll = showAll
        icons = styles.mapValues { (_, f) -> IconRegistry.bitmap(f.icon, sizePx(f.icon, f.iconSize)) }
    }

    private fun iconFor(folder: String): Bitmap = icons[folder] ?: defaultIcon

    override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
        if (shadow) return
        drawnCount = 0
        val proj = mapView.projection
        val showLabels = mapView.zoomLevelDouble >= LABEL_MIN_ZOOM

        if (showAll && points.isNotEmpty()) {
            val bb = proj.boundingBox
            val north = bb.latNorth
            val south = bb.latSouth
            val east = bb.lonEast
            val west = bb.lonWest
            val cell = (6 * density).roundToInt().coerceAtLeast(4)
            val cols = mapView.width / cell + 3
            val rows = mapView.height / cell + 3
            val occupied = BooleanArray(cols * rows)

            for (i in points.indices) {
                val p = points[i]
                if (p.lat > north || p.lat < south) continue
                if (west <= east) {
                    if (p.lon < west || p.lon > east) continue
                } else if (p.lon < west && p.lon > east) continue

                gp.setCoords(p.lat, p.lon)
                proj.toPixels(gp, px)
                val gx = px.x / cell + 1
                val gy = px.y / cell + 1
                if (gx < 0 || gy < 0 || gx >= cols || gy >= rows) continue
                val k = gy * cols + gx
                if (occupied[k]) continue
                occupied[k] = true

                val bmp = iconFor(p.folder)
                canvas.drawBitmap(bmp, px.x - bmp.width / 2f, px.y - bmp.height / 2f, null)
                if (drawnCount < MAX_DRAWN) {
                    drawnX[drawnCount] = px.x.toFloat()
                    drawnY[drawnCount] = px.y.toFloat()
                    drawnIdx[drawnCount] = i
                    drawnCount++
                }
            }

            if (showLabels) {
                val placed = ArrayList<RectF>()
                var count = 0
                for (d in 0 until drawnCount) {
                    if (count >= MAX_LABELS) break
                    val p = points[drawnIdx[d]]
                    val style = styles[p.folder]
                    if ((style?.labelMode ?: FolderInfo.LABEL_ALWAYS) != FolderInfo.LABEL_ALWAYS) continue
                    if (p.id == selected?.id) continue
                    val bmp = iconFor(p.folder)
                    if (labels.draw(canvas, p.label, null, drawnX[d], drawnY[d] + bmp.height / 2f, style?.labelSize ?: 1f, placed)) {
                        count++
                    }
                }
            }
        }

        // The selected point is always drawn, with its label and distance from you.
        selected?.let { s ->
            gp.setCoords(s.lat, s.lon)
            proj.toPixels(gp, px)
            val bmp = iconFor(s.folder)
            val x = px.x.toFloat()
            val y = px.y.toFloat()
            canvas.drawCircle(x, y, max(bmp.width, bmp.height) / 2f + 4 * density, ring)
            canvas.drawBitmap(bmp, x - bmp.width / 2f, y - bmp.height / 2f, null)
            val here = myLocation()
            val distance = here?.let {
                "Distance: " + Geo.formatDistance(Geo.distance(it.latitude, it.longitude, s.lat, s.lon))
            }
            labels.draw(canvas, s.label, distance, x, y + bmp.height / 2f, styles[s.folder]?.labelSize ?: 1f, null)
        }
    }

    override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
        val r = 20 * density
        var best = -1
        var bestD = r * r
        for (d in 0 until drawnCount) {
            val dx = drawnX[d] - e.x
            val dy = drawnY[d] - e.y
            val dd = dx * dx + dy * dy
            if (dd < bestD) {
                bestD = dd
                best = d
            }
        }
        if (best < 0) return false
        val p = points[drawnIdx[best]]
        selected = p
        mapView.invalidate()
        onTap(p.id)
        return true
    }
}
