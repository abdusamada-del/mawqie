package com.example.offlinepoints

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay

/**
 * Your current position, Locus style:
 *  - standing still: blue ring with a dot in the middle
 *  - moving: blue triangle pointing in the direction you are going
 * Grey instead of blue while there is no GPS fix (only an old or network position).
 */
class PositionOverlay(
    ctx: Context,
    private val onUpdate: () -> Unit
) : Overlay(), LocationListener {

    companion object {
        /** GPS fix counts as "available" if newer than this. */
        private const val FIX_MAX_AGE_MS = 15_000L

        /** Faster than this (m/s, about 3.6 km/h) counts as moving. */
        private const val MOVING_SPEED = 1.0f
    }

    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val density = ctx.resources.displayMetrics.density
    private var running = false
    private var lastGpsFixAt = 0L

    var location: Location? = null
        private set

    val myLocation: GeoPoint?
        get() = location?.let { GeoPoint(it.latitude, it.longitude) }

    val hasGpsFix: Boolean
        get() = lastGpsFixAt > 0 && SystemClock.elapsedRealtime() - lastGpsFixAt < FIX_MAX_AGE_MS

    private val blue = 0xFF1565C0.toInt()
    private val grey = 0xFF8A8A8A.toInt()
    private val ringOuter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
        strokeWidth = 4.5f * density
    }
    private val ringInner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
        strokeWidth = 1.8f * density
        strokeJoin = Paint.Join.ROUND
    }
    private val gp = GeoPoint(0.0, 0.0)
    private val px = Point()
    private val triangle = Path()

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 0f, this, Looper.getMainLooper())
            }
            running = true
            if (location == null) {
                location = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                    .mapNotNull {
                        try {
                            lm.getLastKnownLocation(it)
                        } catch (e: Exception) {
                            null
                        }
                    }
                    .maxByOrNull { it.time }
                if (location != null) onUpdate()
            }
        } catch (e: SecurityException) {
            running = false
        }
    }

    fun stop() {
        try {
            lm.removeUpdates(this)
        } catch (e: Exception) {
            // ignore
        }
        running = false
    }

    // ── LocationListener ─────────────────────────────────────────────────────

    override fun onLocationChanged(loc: Location) {
        if (loc.provider == LocationManager.GPS_PROVIDER) {
            lastGpsFixAt = SystemClock.elapsedRealtime()
            location = loc
        } else if (!hasGpsFix) {
            location = loc // use network position only while GPS has no fix
        }
        onUpdate()
    }

    override fun onProviderEnabled(provider: String) {}

    override fun onProviderDisabled(provider: String) {
        onUpdate()
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    // ── Drawing ──────────────────────────────────────────────────────────────

    override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
        if (shadow) return
        val loc = location ?: return
        gp.setCoords(loc.latitude, loc.longitude)
        mapView.projection.toPixels(gp, px)
        val x = px.x.toFloat()
        val y = px.y.toFloat()
        val color = if (hasGpsFix) blue else grey
        val moving = hasGpsFix && loc.hasSpeed() && loc.speed > MOVING_SPEED && loc.hasBearing()

        if (moving) {
            val s = density
            triangle.reset()
            // 1.5x the original size
            triangle.moveTo(0f, -18f * s)
            triangle.lineTo(13.5f * s, 15f * s)
            triangle.lineTo(0f, 8.25f * s)
            triangle.lineTo(-13.5f * s, 15f * s)
            triangle.close()
            canvas.save()
            canvas.translate(x, y)
            canvas.rotate(loc.bearing)
            fill.color = color
            canvas.drawPath(triangle, fill)
            canvas.drawPath(triangle, outline)
            canvas.restore()
        } else {
            val r = 13f * density
            ringInner.color = color
            canvas.drawCircle(x, y, r, ringOuter)
            canvas.drawCircle(x, y, r, ringInner)
            fill.color = color
            val dot = 2.8f * density
            canvas.drawCircle(x, y, dot, fill)
            canvas.drawCircle(x, y, dot, outline)
        }
    }
}
