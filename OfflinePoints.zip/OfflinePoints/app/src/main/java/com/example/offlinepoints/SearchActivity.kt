package com.example.offlinepoints

import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * "Search in points": results sorted by distance from the map center.
 * Each result has an eye button to show or hide it on the map.
 */
class SearchActivity : AppCompatActivity() {

    private lateinit var etQuery: EditText
    private lateinit var cbDesc: CheckBox
    private lateinit var spFolder: Spinner
    private lateinit var tvSummary: TextView
    private lateinit var adapter: PointRowAdapter

    private var folderNames: List<String> = emptyList()
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        Repo.init(this)

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))
        supportActionBar?.title = "Search in points"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        etQuery = findViewById(R.id.etQuery)
        cbDesc = findViewById(R.id.cbDesc)
        spFolder = findViewById(R.id.spFolder)
        tvSummary = findViewById(R.id.tvSummary)

        adapter = PointRowAdapter(
            this,
            showFolder = true,
            onClick = { p ->
                AppState.focusPointId = p.id
                finish()
            },
            onLongClick = { },
            onEye = { p, on -> lifecycleScope.launch(Dispatchers.IO) { Repo.setVisible(p.id, on) } }
        )
        adapter.refLat = AppState.mapCenterLat
        adapter.refLon = AppState.mapCenterLon

        findViewById<RecyclerView>(R.id.results).apply {
            layoutManager = LinearLayoutManager(this@SearchActivity)
            adapter = this@SearchActivity.adapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }

        etQuery.doAfterTextChanged { runSearch(250) }
        etQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(0)
                hideKeyboard()
                true
            } else {
                false
            }
        }
        cbDesc.setOnCheckedChangeListener { _, _ -> runSearch(0) }

        lifecycleScope.launch {
            val folders = withContext(Dispatchers.IO) { Repo.folders() }
            folderNames = folders.map { it.name }
            val icons = HashMap<String, Bitmap>()
            folders.forEach { icons[it.name] = IconRegistry.bitmap(it.icon, IconRegistry.listSizePx(this@SearchActivity, it.icon)) }
            adapter.icons = icons
            spFolder.adapter = ArrayAdapter(
                this@SearchActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("All folders") + folderNames
            )
            spFolder.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    runSearch(0)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
            runSearch(0)
        }

        etQuery.requestFocus()
    }

    private fun runSearch(delayMs: Long) {
        searchJob?.cancel()
        searchJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            val query = etQuery.text.toString()
            val inDesc = cbDesc.isChecked
            val pos = spFolder.selectedItemPosition
            val folder = if (pos <= 0 || pos > folderNames.size) null else folderNames[pos - 1]
            val lat = adapter.refLat
            val lon = adapter.refLon

            val results = withContext(Dispatchers.IO) {
                Repo.search(query, inDesc, folder)
                    .map { it to Geo.distance(lat, lon, it.lat, it.lon) }
                    .sortedBy { it.second }
                    .take(300)
                    .map { it.first }
            }
            adapter.visible.clear()
            results.forEach { if (it.visible) adapter.visible.add(it.id) }
            adapter.submit(results)
            tvSummary.text = when {
                results.isEmpty() && folderNames.isEmpty() -> "No points yet. Import a GPX file first."
                results.isEmpty() -> "No points found"
                query.isBlank() -> "${results.size} nearest points to the map center"
                else -> "${results.size} found, nearest to the map center first"
            }
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etQuery.windowToken, 0)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
