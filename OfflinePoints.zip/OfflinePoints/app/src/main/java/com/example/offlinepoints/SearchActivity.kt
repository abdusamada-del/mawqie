package com.example.offlinepoints

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** "Search in points": type a name, results are sorted by distance from the map center. */
class SearchActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CENTER_LAT = "center_lat"
        const val EXTRA_CENTER_LON = "center_lon"
        const val EXTRA_LAT = "lat"
        const val EXTRA_LON = "lon"
        const val EXTRA_NAME = "name"
    }

    private lateinit var etQuery: EditText
    private lateinit var cbDesc: CheckBox
    private lateinit var spFolder: Spinner
    private lateinit var tvSummary: TextView

    private val adapter = ResultAdapter { point -> pick(point) }
    private var folderNames: List<String> = emptyList()
    private var centerLat = 0.0
    private var centerLon = 0.0
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))
        supportActionBar?.title = "Search in points"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        centerLat = intent.getDoubleExtra(EXTRA_CENTER_LAT, 0.0)
        centerLon = intent.getDoubleExtra(EXTRA_CENTER_LON, 0.0)

        etQuery = findViewById(R.id.etQuery)
        cbDesc = findViewById(R.id.cbDesc)
        spFolder = findViewById(R.id.spFolder)
        tvSummary = findViewById(R.id.tvSummary)

        findViewById<RecyclerView>(R.id.results).apply {
            layoutManager = LinearLayoutManager(this@SearchActivity)
            adapter = this@SearchActivity.adapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }

        folderNames = PointStore.folders(this).map { it.first }
        spFolder.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("All folders") + folderNames
        )
        spFolder.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                runSearch(0)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        etQuery.doAfterTextChanged { runSearch(250) }
        etQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(0)
                hideKeyboard()
                true
            } else {
                false
            }
        }
        cbDesc.setOnCheckedChangeListener { _, _ -> runSearch(0) }

        etQuery.requestFocus()
        runSearch(0)
    }

    private fun runSearch(delayMs: Long) {
        searchJob?.cancel()
        searchJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            val query = etQuery.text.toString()
            val inDesc = cbDesc.isChecked
            val pos = spFolder.selectedItemPosition
            val folder = if (pos <= 0) null else folderNames[pos - 1]

            val results = withContext(Dispatchers.Default) {
                PointStore.search(this@SearchActivity, query, inDesc, folder, centerLat, centerLon)
            }
            adapter.submit(results)
            tvSummary.text = when {
                results.isEmpty() && folderNames.isEmpty() -> "No points yet. Import a GPX file first."
                results.isEmpty() -> "No points found"
                query.isBlank() -> "${results.size} nearest points to the map center"
                else -> "${results.size} found, nearest to the map center first"
            }
        }
    }

    private fun pick(p: GpxPoint) {
        setResult(
            RESULT_OK,
            Intent()
                .putExtra(EXTRA_LAT, p.lat)
                .putExtra(EXTRA_LON, p.lon)
                .putExtra(EXTRA_NAME, p.name)
        )
        finish()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etQuery.windowToken, 0)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}

class ResultAdapter(
    private val onClick: (GpxPoint) -> Unit
) : RecyclerView.Adapter<ResultAdapter.Holder>() {

    private var items: List<Pair<GpxPoint, Float>> = emptyList()

    fun submit(list: List<Pair<GpxPoint, Float>>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_point, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val (p, meters) = items[position]
        holder.tvName.text = p.label
        holder.tvSub.text = "${p.folder}  ·  ${p.coords}"
        holder.tvDistance.text = formatDistance(meters)
        holder.itemView.setOnClickListener { onClick(p) }
    }

    override fun getItemCount(): Int = items.size

    private fun formatDistance(m: Float): String =
        if (m < 1000) String.format(Locale.US, "%.0f m", m)
        else String.format(Locale.US, "%.1f km", m / 1000)

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tvPointName)
        val tvSub: TextView = v.findViewById(R.id.tvPointSub)
        val tvDistance: TextView = v.findViewById(R.id.tvDistance)
    }
}
