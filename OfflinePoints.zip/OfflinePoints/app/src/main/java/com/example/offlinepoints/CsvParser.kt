package com.example.offlinepoints

/**
 * Reads points from a CSV (or tab/semicolon separated) text file.
 * Understands common column names, a single "coordinates" column, or no header at all.
 */
object CsvParser {

    class Result(val points: List<GpxPoint>, val skipped: Int)

    private val LAT = listOf("lat", "latitude", "y", "lat_dd", "lat dd", "northing")
    private val LON = listOf("lon", "lng", "long", "longitude", "x", "lon_dd", "lon dd", "easting")
    private val NAME = listOf("name", "title", "label", "id", "point", "point name", "pointname", "code", "number", "no", "ref")
    private val DESC = listOf("desc", "description", "comment", "comments", "note", "notes", "remark", "remarks", "details")
    private val ELE = listOf("ele", "elevation", "alt", "altitude", "height", "z")
    private val COORD = listOf("coordinates", "coordinate", "coords", "location", "latlon", "lat/lon", "lat,lon", "position", "gps")

    fun parse(text: String, folder: String): Result {
        val clean = text.removePrefix("﻿")
        val firstLine = clean.lineSequence().firstOrNull { it.isNotBlank() } ?: return Result(emptyList(), 0)
        val sep = detectSeparator(firstLine)
        val rows = splitRows(clean, sep).filter { r -> r.any { it.isNotBlank() } }
        if (rows.isEmpty()) return Result(emptyList(), 0)

        val header = rows[0].map { normalize(it) }
        val hasHeader = header.any { h -> h in LAT || h in LON || h in COORD || h.startsWith("lat") || h.startsWith("lon") }
        val data = if (hasHeader) rows.drop(1) else rows

        var latCol = -1
        var lonCol = -1
        var coordCol = -1
        var nameCol = -1
        var descCol = -1
        var eleCol = -1

        if (hasHeader) {
            latCol = findColumn(header, LAT) { it.startsWith("lat") }
            lonCol = findColumn(header, LON) { it.startsWith("lon") || it.startsWith("lng") }
            coordCol = findColumn(header, COORD) { it.contains("coord") }
            nameCol = findColumn(header, NAME) { it.contains("name") }
            descCol = findColumn(header, DESC) { it.startsWith("desc") }
            eleCol = findColumn(header, ELE) { it.startsWith("elev") || it.startsWith("alt") }
        } else {
            // No header: the first two columns holding numbers are latitude and longitude
            val sample = data.take(20)
            val numericCols = (0 until (sample.maxOfOrNull { it.size } ?: 0)).filter { c ->
                sample.count { r -> toNumber(r.getOrNull(c), sep) != null } >= (sample.size + 1) / 2
            }
            if (numericCols.size >= 2) {
                latCol = numericCols[0]
                lonCol = numericCols[1]
            }
            nameCol = (0 until (sample.maxOfOrNull { it.size } ?: 0)).firstOrNull { it !in numericCols } ?: -1
        }

        if ((latCol < 0 || lonCol < 0) && coordCol < 0) {
            error("Could not find latitude and longitude columns. Use headers like Name, Lat, Lon.")
        }

        val points = ArrayList<GpxPoint>()
        var skipped = 0
        for (r in data) {
            var lat: Double?
            var lon: Double?
            if (latCol >= 0 && lonCol >= 0) {
                lat = toNumber(r.getOrNull(latCol), sep)
                lon = toNumber(r.getOrNull(lonCol), sep)
            } else {
                val nums = Regex("-?\\d+(?:\\.\\d+)?").findAll(r.getOrNull(coordCol).orEmpty())
                    .map { it.value.toDouble() }.toList()
                lat = nums.getOrNull(0)
                lon = nums.getOrNull(1)
            }
            if (lat == null || lon == null) {
                skipped++
                continue
            }
            // Columns in the other order (longitude first)?
            if (kotlin.math.abs(lat) > 90 && kotlin.math.abs(lon) <= 90) {
                val t = lat
                lat = lon
                lon = t
            }
            if (kotlin.math.abs(lat) > 90 || kotlin.math.abs(lon) > 180) {
                skipped++
                continue
            }
            points.add(
                GpxPoint(
                    folder = folder,
                    name = r.getOrNull(nameCol)?.trim().orEmpty(),
                    desc = r.getOrNull(descCol)?.trim().orEmpty(),
                    lat = lat,
                    lon = lon,
                    ele = toNumber(r.getOrNull(eleCol), sep)
                )
            )
        }
        return Result(points, skipped)
    }

    private fun normalize(s: String) = s.trim().trim('"').trim().lowercase()

    private fun findColumn(header: List<String>, names: List<String>, loose: (String) -> Boolean): Int {
        val exact = header.indexOfFirst { it in names }
        return if (exact >= 0) exact else header.indexOfFirst(loose)
    }

    private fun toNumber(raw: String?, sep: Char): Double? {
        var s = raw?.trim()?.trim('"')?.trim() ?: return null
        if (s.isEmpty()) return null
        if (sep != ',' && s.count { it == ',' } == 1 && !s.contains('.')) s = s.replace(',', '.') // decimal comma
        return s.toDoubleOrNull()
    }

    private fun detectSeparator(line: String): Char {
        val counts = listOf(',', ';', '\t').associateWith { c -> countOutsideQuotes(line, c) }
        return counts.maxByOrNull { it.value }?.takeIf { it.value > 0 }?.key ?: ','
    }

    private fun countOutsideQuotes(line: String, c: Char): Int {
        var inQ = false
        var n = 0
        for (ch in line) {
            if (ch == '"') inQ = !inQ else if (ch == c && !inQ) n++
        }
        return n
    }

    /** Splits text into rows of cells, handling quotes (including line breaks inside quotes). */
    private fun splitRows(text: String, sep: Char): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var inQ = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (inQ) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        cell.append('"')
                        i++
                    } else {
                        inQ = false
                    }
                } else {
                    cell.append(ch)
                }
            } else {
                when (ch) {
                    '"' -> inQ = true
                    sep -> {
                        row.add(cell.toString())
                        cell.setLength(0)
                    }
                    '\r' -> {}
                    '\n' -> {
                        row.add(cell.toString())
                        cell.setLength(0)
                        rows.add(row)
                        row = ArrayList()
                    }
                    else -> cell.append(ch)
                }
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) {
            row.add(cell.toString())
            rows.add(row)
        }
        return rows
    }
}
