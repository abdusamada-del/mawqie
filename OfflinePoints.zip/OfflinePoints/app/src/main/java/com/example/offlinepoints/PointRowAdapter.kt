package com.example.offlinepoints

import android.content.Context
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * One row per point: icon, name, direction arrow + distance, date,
 * and an eye button (or a checkbox while selecting).
 */
class PointRowAdapter(
    private val ctx: Context,
    private val showFolder: Boolean,
    private val onClick: (GpxPoint) -> Unit,
    private val onLongClick: (GpxPoint) -> Unit,
    private val onEye: (GpxPoint, Boolean) -> Unit
) : RecyclerView.Adapter<PointRowAdapter.Holder>() {

    var items: List<GpxPoint> = emptyList()
        private set

    /** Ids of points whose eye is open. */
    val visible = HashSet<Long>()
    val selected = HashSet<Long>()
    var selecting = false
    var refLat = 0.0
    var refLon = 0.0

    /** Folder name -> icon shown in the row. */
    var icons: Map<String, Bitmap> = emptyMap()
    private val defaultIcon = IconRegistry.bitmap(IconRegistry.DEFAULT, IconRegistry.listSizePx(ctx, IconRegistry.DEFAULT))

    fun submit(list: List<GpxPoint>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_point, parent, false))

    override fun onBindViewHolder(h: Holder, position: Int) {
        val p = items[position]
        h.icon.setImageBitmap(icons[p.folder] ?: defaultIcon)
        h.name.text = p.label
        h.distance.text = Geo.formatDistance(Geo.distance(refLat, refLon, p.lat, p.lon))
        h.arrow.rotation = Geo.bearing(refLat, refLon, p.lat, p.lon)
        val date = Geo.formatDate(p.created)
        h.date.text = date
        h.calendar.visibility = if (date.isEmpty()) View.GONE else View.VISIBLE
        if (showFolder) {
            h.folder.visibility = View.VISIBLE
            h.folder.text = p.folder
        } else {
            h.folder.visibility = View.GONE
        }

        if (selecting) {
            h.eye.visibility = View.GONE
            h.check.visibility = View.VISIBLE
            h.check.isChecked = p.id in selected
        } else {
            h.check.visibility = View.GONE
            h.eye.visibility = View.VISIBLE
            val on = p.id in visible
            h.eye.setImageResource(if (on) R.drawable.ic_eye else R.drawable.ic_eye_off_row)
            h.eye.setBackgroundResource(if (on) R.drawable.bg_eye_on else 0)
        }

        h.itemView.setOnClickListener { onClick(p) }
        h.itemView.setOnLongClickListener {
            onLongClick(p)
            true
        }
        h.eye.setOnClickListener {
            val nowOn = p.id !in visible
            if (nowOn) visible.add(p.id) else visible.remove(p.id)
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos)
            onEye(p, nowOn)
        }
    }

    override fun getItemCount(): Int = items.size

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.ivPointIcon)
        val name: TextView = v.findViewById(R.id.tvPointName)
        val arrow: ImageView = v.findViewById(R.id.ivArrow)
        val distance: TextView = v.findViewById(R.id.tvDistance)
        val calendar: ImageView = v.findViewById(R.id.ivCalendar)
        val date: TextView = v.findViewById(R.id.tvDate)
        val folder: TextView = v.findViewById(R.id.tvPointFolder)
        val eye: ImageButton = v.findViewById(R.id.btnEye)
        val check: CheckBox = v.findViewById(R.id.cbSelect)
    }
}
