package com.example.offlinepoints

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A folder opened: its points, eye buttons, sorting and selection. */
class FolderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_FOLDER = "folder"
    }

    private lateinit var folder: String
    private lateinit var adapter: PointRowAdapter
    private lateinit var tvCount: TextView
    private lateinit var tvSelCount: TextView
    private lateinit var normalTop: View
    private lateinit var selectTop: View
    private lateinit var normalBottom: View
    private lateinit var selectBottom: View

    /** Points in the current sort order. */
    private var points: List<GpxPoint> = emptyList()
    private val distances = HashMap<Long, Float>()
    private val prefs by lazy { getSharedPreferences("mawqie", MODE_PRIVATE) }

    private val selectionBack = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = exitSelection()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        folder = intent.getStringExtra(EXTRA_FOLDER) ?: run {
            finish()
            return
        }
        setContentView(R.layout.activity_folder)

        tvCount = findViewById(R.id.tvCount)
        tvSelCount = findViewById(R.id.tvSelCount)
        normalTop = findViewById(R.id.normalTop)
        selectTop = findViewById(R.id.selectTop)
        normalBottom = findViewById(R.id.normalBottom)
        selectBottom = findViewById(R.id.selectBottom)
        findViewById<TextView>(R.id.tvTitle).text = folder

        adapter = PointRowAdapter(
            this,
            showFolder = false,
            onClick = { p -> onRowClick(p) },
            onLongClick = { p -> if (adapter.selecting) toggleSelect(p) else enterSelection(p) },
            onEye = { p, on ->
                lifecycleScope.launch(Dispatchers.IO) { Repo.setVisible(p.id, on) }
                updateCounts()
            }
        )
        val ref = Geo.referenceLocation(this)
        adapter.refLat = ref.first
        adapter.refLon = ref.second

        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@FolderActivity)
            adapter = this@FolderActivity.adapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }

        onBackPressedDispatcher.addCallback(this, selectionBack)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnEyeMenu).setOnClickListener { showEyeMenu(it) }
        findViewById<View>(R.id.btnSort).setOnClickListener { showSortMenu(it) }
        findViewById<View>(R.id.btnCloseSel).setOnClickListener { exitSelection() }
        findViewById<View>(R.id.btnSelMenu).setOnClickListener { showSelectMenu(it) }
        findViewById<View>(R.id.btnCopy).setOnClickListener { copyOrMove(move = false) }
        findViewById<View>(R.id.btnMove).setOnClickListener { copyOrMove(move = true) }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    // ── Loading & sorting ────────────────────────────────────────────────────

    private fun load() {
        lifecycleScope.launch {
            val (pts, info) = withContext(Dispatchers.IO) { Repo.folderPoints(folder) to Repo.folder(folder) }
            if (info == null && pts.isEmpty()) {
                finish() // folder was deleted or renamed
                return@launch
            }
            if (info != null) {
                adapter.icons = mapOf(folder to IconRegistry.bitmap(info.icon, IconRegistry.listSizePx(this@FolderActivity, info.icon)))
            }
            adapter.visible.clear()
            pts.forEach { if (it.visible) adapter.visible.add(it.id) }
            val ids = pts.mapTo(HashSet()) { it.id }
            adapter.selected.retainAll(ids)
            distances.clear()
            pts.forEach { distances[it.id] = Geo.distance(adapter.refLat, adapter.refLon, it.lat, it.lon) }
            points = sortList(pts)
            adapter.submit(points)
            updateCounts()
        }
    }

    private fun sortList(list: List<GpxPoint>): List<GpxPoint> {
        val sorted = when (prefs.getString("sort", "name")) {
            "distance" -> list.sortedBy { distances[it.id] ?: 0f }
            "created" -> list.sortedByDescending { it.created }
            "updated" -> list.sortedByDescending { it.updated }
            else -> list.sortedWith(compareBy(NaturalOrder) { it.label })
        }
        return if (prefs.getBoolean("reverse", false)) sorted.reversed() else sorted
    }

    private fun updateCounts() {
        tvCount.text = "${adapter.visible.size} / ${points.size}"
        tvSelCount.text = "${adapter.selected.size} Points"
    }

    // ── Rows ─────────────────────────────────────────────────────────────────

    private fun onRowClick(p: GpxPoint) {
        if (adapter.selecting) {
            toggleSelect(p)
            return
        }
        AppState.focusPointId = p.id
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    // ── Eye menu ─────────────────────────────────────────────────────────────

    private fun showEyeMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Display all")
        pm.menu.add(0, 2, 1, "Hide all")
        pm.menu.add(0, 3, 2, "First X points")
        pm.menu.add(0, 4, 3, "Invert")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> bulk { Repo.setFolderVisible(folder, true) }
                2 -> bulk { Repo.setFolderVisible(folder, false) }
                3 -> Dialogs.askText(this, "Show first X points", "50", "Number of points", number = true) { t ->
                    val x = t.toIntOrNull() ?: return@askText
                    val ids = points.take(x).map { it.id }
                    bulk { report -> Repo.showOnly(folder, ids, report) }
                }
                4 -> bulk { Repo.invertFolder(folder) }
            }
            true
        }
        pm.show()
    }

    private fun bulk(work: ((Int) -> Unit) -> Unit) {
        Dialogs.runWithProgress(this, "Working…", work) { result ->
            result.onFailure { toast("Failed: ${it.message}") }
            load()
        }
    }

    // ── Sort menu ────────────────────────────────────────────────────────────

    private fun showSortMenu(anchor: View) {
        val modes = listOf("name" to "Name", "distance" to "Distance", "created" to "Created", "updated" to "Updated")
        val current = prefs.getString("sort", "name")
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        modes.forEachIndexed { i, (_, label) -> m.add(1, i + 1, i, label) }
        m.setGroupCheckable(1, true, true)
        modes.forEachIndexed { i, (key, _) -> m.findItem(i + 1).isChecked = key == current }
        val rev = m.add(2, 10, 10, "Reverse sorting")
        rev.isCheckable = true
        rev.isChecked = prefs.getBoolean("reverse", false)
        pm.setOnMenuItemClickListener { item ->
            if (item.itemId == 10) {
                prefs.edit().putBoolean("reverse", !prefs.getBoolean("reverse", false)).apply()
            } else {
                prefs.edit().putString("sort", modes[item.itemId - 1].first).apply()
            }
            points = sortList(points)
            adapter.submit(points)
            true
        }
        pm.show()
    }

    // ── Selection ────────────────────────────────────────────────────────────

    private fun enterSelection(p: GpxPoint) {
        adapter.selecting = true
        adapter.selected.clear()
        adapter.selected.add(p.id)
        setSelectionBars(true)
        adapter.notifyDataSetChanged()
        updateCounts()
    }

    private fun exitSelection() {
        adapter.selecting = false
        adapter.selected.clear()
        setSelectionBars(false)
        adapter.notifyDataSetChanged()
        updateCounts()
    }

    private fun setSelectionBars(on: Boolean) {
        normalTop.visibility = if (on) View.GONE else View.VISIBLE
        selectTop.visibility = if (on) View.VISIBLE else View.GONE
        normalBottom.visibility = if (on) View.GONE else View.VISIBLE
        selectBottom.visibility = if (on) View.VISIBLE else View.GONE
        selectionBack.isEnabled = on
    }

    private fun toggleSelect(p: GpxPoint) {
        if (!adapter.selected.add(p.id)) adapter.selected.remove(p.id)
        val pos = points.indexOf(p)
        if (pos >= 0) adapter.notifyItemChanged(pos) else adapter.notifyDataSetChanged()
        updateCounts()
    }

    private fun showSelectMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Select all")
        pm.menu.add(0, 2, 1, "Invert selection")
        pm.setOnMenuItemClickListener { item ->
            if (item.itemId == 1) {
                points.forEach { adapter.selected.add(it.id) }
            } else {
                val now = HashSet(adapter.selected)
                adapter.selected.clear()
                points.forEach { if (it.id !in now) adapter.selected.add(it.id) }
            }
            adapter.notifyDataSetChanged()
            updateCounts()
            true
        }
        pm.show()
    }

    private fun copyOrMove(move: Boolean) {
        val ids = points.filter { it.id in adapter.selected }.map { it.id }
        if (ids.isEmpty()) {
            toast("Nothing selected")
            return
        }
        Dialogs.chooseFolder(this, if (move) "Move to" else "Copy to", exclude = folder) { target ->
            Dialogs.runWithProgress(this, "Working…", { report ->
                if (move) Repo.moveTo(ids, target, report) else Repo.copyTo(ids, target, report)
            }) { result ->
                result.onSuccess {
                    toast((if (move) "Moved " else "Copied ") + "${ids.size} points to \"$target\"")
                }.onFailure { toast("Failed: ${it.message}") }
                exitSelection()
                load()
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
