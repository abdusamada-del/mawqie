package com.example.offlinepoints

import java.util.Locale

/** One saved point. */
data class GpxPoint(
    val id: Long = 0,
    val folder: String = "",
    val name: String = "",
    val desc: String = "",
    val lat: Double,
    val lon: Double,
    val ele: Double? = null,
    /** Milliseconds since 1970. From the GPX <time>, or the import time. */
    val created: Long = 0,
    /** Milliseconds since 1970. Import time, or when the point was last moved. */
    val updated: Long = 0,
    val visible: Boolean = true
) {
    val label: String
        get() = name.ifBlank { String.format(Locale.US, "%.5f, %.5f", lat, lon) }

    val coords: String
        get() = String.format(Locale.US, "%.6f, %.6f", lat, lon)
}

/** A folder of points, its look on the map, and how many points it has. */
data class FolderInfo(
    val name: String,
    val group: String? = null,
    val icon: String = IconRegistry.DEFAULT,
    val labelMode: Int = LABEL_ALWAYS,
    val iconSize: Float = 1f,
    val labelSize: Float = 1f,
    val total: Int = 0,
    val visibleCount: Int = 0
) {
    companion object {
        const val LABEL_NEVER = 0
        const val LABEL_TAP = 1
        const val LABEL_ALWAYS = 2
    }
}

/** Lightweight copy of a point for drawing on the map. */
class MapPoint(
    val id: Long,
    val lat: Double,
    val lon: Double,
    val label: String,
    val folder: String
) {
    companion object {
        fun from(p: GpxPoint) = MapPoint(p.id, p.lat, p.lon, p.label, p.folder)
    }
}

/** Small shared state between screens. */
object AppState {
    /** A point the map should jump to when it is shown again (-1 = none). */
    @Volatile
    var focusPointId: Long = -1

    @Volatile
    var mapCenterLat = 25.2048

    @Volatile
    var mapCenterLon = 55.2708

    @Volatile
    var lastFixLat: Double? = null

    @Volatile
    var lastFixLon: Double? = null
}

/** Sorts "PK2" before "PK10" (numbers compared as numbers). */
object NaturalOrder : Comparator<String> {
    override fun compare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ei = i
                while (ei < a.length && a[ei].isDigit()) ei++
                var ej = j
                while (ej < b.length && b[ej].isDigit()) ej++
                val na = a.substring(i, ei).trimStart('0')
                val nb = b.substring(j, ej).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = ei
                j = ej
            } else {
                val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }
}
