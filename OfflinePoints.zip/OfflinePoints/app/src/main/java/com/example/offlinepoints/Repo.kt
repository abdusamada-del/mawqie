package com.example.offlinepoints

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import org.json.JSONArray
import java.io.File
import kotlin.math.max

/**
 * All points and folders, stored in a small database inside the app.
 * Everything here works without internet.
 */
object Repo {

    private const val DB_NAME = "mawqie.db"
    private const val P_COLS = "id, folder, name, descr, lat, lon, ele, created, updated, visible"
    private var helper: Helper? = null

    @Synchronized
    fun init(ctx: Context) {
        if (helper != null) return
        helper = Helper(ctx.applicationContext)
        migrateOldJson(ctx.applicationContext)
    }

    private fun db(): SQLiteDatabase = helper!!.writableDatabase

    private class Helper(ctx: Context) : SQLiteOpenHelper(ctx, DB_NAME, null, 3) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE points (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "folder TEXT NOT NULL, " +
                    "name TEXT NOT NULL DEFAULT '', " +
                    "descr TEXT NOT NULL DEFAULT '', " +
                    "lat REAL NOT NULL, lon REAL NOT NULL, ele REAL, " +
                    "created INTEGER NOT NULL DEFAULT 0, " +
                    "updated INTEGER NOT NULL DEFAULT 0, " +
                    "visible INTEGER NOT NULL DEFAULT 1)"
            )
            db.execSQL("CREATE INDEX idx_points_folder ON points(folder)")
            db.execSQL("CREATE INDEX idx_points_visible ON points(visible)")
            db.execSQL(
                "CREATE TABLE folders (" +
                    "name TEXT PRIMARY KEY, grp TEXT, icon TEXT NOT NULL, " +
                    "label_mode INTEGER NOT NULL, icon_size REAL NOT NULL, label_size REAL NOT NULL)"
            )
            db.execSQL("CREATE TABLE folder_groups (name TEXT PRIMARY KEY)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 2) db.execSQL("CREATE TABLE IF NOT EXISTS folder_groups (name TEXT PRIMARY KEY)")
            // Label size 1.0 now means the old 0.8: start every folder at the new default
            if (oldVersion < 3) db.execSQL("UPDATE folders SET label_size = 1.0")
        }
    }

    private fun readPoint(c: Cursor) = GpxPoint(
        id = c.getLong(0),
        folder = c.getString(1),
        name = c.getString(2),
        desc = c.getString(3),
        lat = c.getDouble(4),
        lon = c.getDouble(5),
        ele = if (c.isNull(6)) null else c.getDouble(6),
        created = c.getLong(7),
        updated = c.getLong(8),
        visible = c.getInt(9) != 0
    )

    private fun queryPoints(sql: String, args: Array<String>?): List<GpxPoint> =
        db().rawQuery(sql, args).use { c ->
            val list = ArrayList<GpxPoint>(c.count)
            while (c.moveToNext()) list.add(readPoint(c))
            list
        }

    private fun ensureFolder(db: SQLiteDatabase, name: String) {
        db.execSQL(
            "INSERT OR IGNORE INTO folders(name, grp, icon, label_mode, icon_size, label_size) " +
                "VALUES (?, NULL, ?, ?, 1.0, 1.0)",
            arrayOf<Any>(name, IconRegistry.DEFAULT, FolderInfo.LABEL_ALWAYS)
        )
    }

    private inline fun <T> tx(block: (SQLiteDatabase) -> T): T {
        val db = db()
        db.beginTransaction()
        try {
            val r = block(db)
            db.setTransactionSuccessful()
            return r
        } finally {
            db.endTransaction()
        }
    }

    /** Runs [block] for each chunk of ids (as "1,2,3"), reporting 0-100 progress. */
    private fun inChunks(ids: List<Long>, progress: (Int) -> Unit, block: (String) -> Unit) {
        val chunks = ids.chunked(400)
        chunks.forEachIndexed { i, chunk ->
            block(chunk.joinToString(","))
            progress((i + 1) * 100 / max(1, chunks.size))
        }
    }

    // ── Folders ──────────────────────────────────────────────────────────────

    fun folders(): List<FolderInfo> {
        val db = db()
        val counts = HashMap<String, IntArray>()
        db.rawQuery("SELECT folder, COUNT(*), SUM(visible) FROM points GROUP BY folder", null).use { c ->
            while (c.moveToNext()) counts[c.getString(0)] = intArrayOf(c.getInt(1), c.getInt(2))
        }
        if (counts.isNotEmpty()) tx { d -> counts.keys.forEach { ensureFolder(d, it) } }

        val list = ArrayList<FolderInfo>()
        db.rawQuery("SELECT name, grp, icon, label_mode, icon_size, label_size FROM folders", null).use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0)
                val cnt = counts[n]
                list.add(
                    FolderInfo(
                        name = n,
                        group = if (c.isNull(1)) null else c.getString(1),
                        icon = c.getString(2),
                        labelMode = c.getInt(3),
                        iconSize = c.getFloat(4),
                        labelSize = c.getFloat(5),
                        total = cnt?.get(0) ?: 0,
                        visibleCount = cnt?.get(1) ?: 0
                    )
                )
            }
        }
        return list.sortedWith(compareBy(NaturalOrder) { it.name })
    }

    fun folder(name: String): FolderInfo? = folders().firstOrNull { it.name == name }

    /** All group names: groups saved on their own plus groups used by folders. */
    fun groups(): List<String> {
        val names = HashSet<String>()
        db().rawQuery("SELECT name FROM folder_groups", null).use { c -> while (c.moveToNext()) names.add(c.getString(0)) }
        db().rawQuery("SELECT DISTINCT grp FROM folders WHERE grp IS NOT NULL", null).use { c ->
            while (c.moveToNext()) names.add(c.getString(0))
        }
        return names.sortedWith(NaturalOrder)
    }

    fun createGroup(name: String) {
        db().execSQL("INSERT OR IGNORE INTO folder_groups(name) VALUES (?)", arrayOf<Any>(name))
    }

    /** Returns false if another group already has [newName]. */
    fun renameGroup(oldName: String, newName: String): Boolean {
        if (oldName == newName) return true
        if (groups().contains(newName)) return false
        tx { db ->
            db.execSQL("UPDATE folders SET grp = ? WHERE grp = ?", arrayOf<Any>(newName, oldName))
            db.delete("folder_groups", "name = ?", arrayOf(oldName))
            db.execSQL("INSERT OR IGNORE INTO folder_groups(name) VALUES (?)", arrayOf<Any>(newName))
        }
        return true
    }

    /** Removes the group. Its folders and points are kept, just no longer in a group. */
    fun deleteGroup(name: String) = tx { db ->
        db.execSQL("UPDATE folders SET grp = NULL WHERE grp = ?", arrayOf<Any>(name))
        db.delete("folder_groups", "name = ?", arrayOf(name))
    }

    fun createFolder(name: String) = tx { ensureFolder(it, name) }

    /** Saves folder settings. Returns false if renaming to a name that already exists. */
    fun saveFolder(oldName: String, info: FolderInfo): Boolean {
        val db = db()
        db.beginTransaction()
        try {
            if (info.name != oldName) {
                val taken = DatabaseUtils.longForQuery(
                    db, "SELECT COUNT(*) FROM folders WHERE name = ?", arrayOf(info.name)
                ) > 0
                if (taken) return false
                db.execSQL("UPDATE points SET folder = ? WHERE folder = ?", arrayOf<Any>(info.name, oldName))
                db.delete("folders", "name = ?", arrayOf(oldName))
            }
            val cv = ContentValues()
            cv.put("name", info.name)
            if (info.group == null) cv.putNull("grp") else cv.put("grp", info.group)
            cv.put("icon", info.icon)
            cv.put("label_mode", info.labelMode)
            cv.put("icon_size", info.iconSize)
            cv.put("label_size", info.labelSize)
            db.insertWithOnConflict("folders", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            info.group?.let { db.execSQL("INSERT OR IGNORE INTO folder_groups(name) VALUES (?)", arrayOf<Any>(it)) }
            db.setTransactionSuccessful()
            return true
        } finally {
            db.endTransaction()
        }
    }

    fun deleteFolder(name: String) = tx { db ->
        db.delete("points", "folder = ?", arrayOf(name))
        db.delete("folders", "name = ?", arrayOf(name))
    }

    // ── Points ───────────────────────────────────────────────────────────────

    /** Adds points to [folder]. With [replace], the folder's old points are removed first. */
    fun addPoints(folder: String, pts: List<GpxPoint>, replace: Boolean, progress: (Int) -> Unit = {}) {
        val now = System.currentTimeMillis()
        tx { db ->
            ensureFolder(db, folder)
            if (replace) db.delete("points", "folder = ?", arrayOf(folder))
            val st = db.compileStatement(
                "INSERT INTO points(folder, name, descr, lat, lon, ele, created, updated, visible) " +
                    "VALUES (?,?,?,?,?,?,?,?,1)"
            )
            pts.forEachIndexed { i, p ->
                st.clearBindings()
                st.bindString(1, folder)
                st.bindString(2, p.name)
                st.bindString(3, p.desc)
                st.bindDouble(4, p.lat)
                st.bindDouble(5, p.lon)
                val ele = p.ele
                if (ele != null) st.bindDouble(6, ele) else st.bindNull(6)
                st.bindLong(7, if (p.created > 0) p.created else now)
                st.bindLong(8, now)
                st.executeInsert()
                if (i % 500 == 0) progress(i * 100 / max(1, pts.size))
            }
            progress(100)
        }
    }

    fun point(id: Long): GpxPoint? =
        queryPoints("SELECT $P_COLS FROM points WHERE id = ?", arrayOf(id.toString())).firstOrNull()

    fun folderPoints(folder: String): List<GpxPoint> =
        queryPoints("SELECT $P_COLS FROM points WHERE folder = ?", arrayOf(folder))

    /** All points that are switched on (eye open), for drawing on the map. */
    fun visiblePoints(): List<MapPoint> =
        db().rawQuery("SELECT id, lat, lon, name, folder FROM points WHERE visible = 1", null).use { c ->
            val list = ArrayList<MapPoint>(c.count)
            while (c.moveToNext()) {
                val lat = c.getDouble(1)
                val lon = c.getDouble(2)
                val name = c.getString(3)
                val label = name.ifBlank { String.format(java.util.Locale.US, "%.5f, %.5f", lat, lon) }
                list.add(MapPoint(c.getLong(0), lat, lon, label, c.getString(4)))
            }
            list
        }

    fun search(query: String, inDescription: Boolean, folder: String?): List<GpxPoint> {
        val where = StringBuilder("1=1")
        val args = ArrayList<String>()
        if (folder != null) {
            where.append(" AND folder = ?")
            args.add(folder)
        }
        val q = query.trim()
        if (q.isNotEmpty()) {
            val like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
            if (inDescription) {
                where.append(" AND (name LIKE ? ESCAPE '\\' OR descr LIKE ? ESCAPE '\\')")
                args.add(like)
                args.add(like)
            } else {
                where.append(" AND name LIKE ? ESCAPE '\\'")
                args.add(like)
            }
        }
        return queryPoints("SELECT $P_COLS FROM points WHERE $where", args.toTypedArray())
    }

    fun setVisible(id: Long, visible: Boolean) {
        db().execSQL("UPDATE points SET visible = ? WHERE id = ?", arrayOf<Any>(if (visible) 1 else 0, id))
    }

    fun setFolderVisible(folder: String, visible: Boolean) {
        db().execSQL("UPDATE points SET visible = ? WHERE folder = ?", arrayOf<Any>(if (visible) 1 else 0, folder))
    }

    fun invertFolder(folder: String) {
        db().execSQL("UPDATE points SET visible = 1 - visible WHERE folder = ?", arrayOf<Any>(folder))
    }

    /** Hides every point of [folder] except [ids]. */
    fun showOnly(folder: String, ids: List<Long>, progress: (Int) -> Unit) = tx { db ->
        db.execSQL("UPDATE points SET visible = 0 WHERE folder = ?", arrayOf<Any>(folder))
        inChunks(ids, progress) { db.execSQL("UPDATE points SET visible = 1 WHERE id IN ($it)") }
    }

    fun copyTo(ids: List<Long>, target: String, progress: (Int) -> Unit) = tx { db ->
        ensureFolder(db, target)
        val now = System.currentTimeMillis()
        inChunks(ids, progress) {
            db.execSQL(
                "INSERT INTO points(folder, name, descr, lat, lon, ele, created, updated, visible) " +
                    "SELECT ?, name, descr, lat, lon, ele, created, $now, visible FROM points WHERE id IN ($it)",
                arrayOf<Any>(target)
            )
        }
    }

    fun moveTo(ids: List<Long>, target: String, progress: (Int) -> Unit) = tx { db ->
        ensureFolder(db, target)
        val now = System.currentTimeMillis()
        inChunks(ids, progress) {
            db.execSQL("UPDATE points SET folder = ?, updated = $now WHERE id IN ($it)", arrayOf<Any>(target))
        }
    }

    // ── One-time move of points saved by version 1.x ─────────────────────────

    private fun migrateOldJson(ctx: Context) {
        val file = File(ctx.filesDir, "points.json")
        if (!file.exists()) return
        try {
            val arr = JSONArray(file.readText())
            val byFolder = LinkedHashMap<String, ArrayList<GpxPoint>>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val folder = o.optString("folder", "Imported")
                byFolder.getOrPut(folder) { ArrayList() }.add(
                    GpxPoint(
                        name = o.optString("name", ""),
                        desc = o.optString("desc", ""),
                        lat = o.getDouble("lat"),
                        lon = o.getDouble("lon"),
                        ele = if (o.has("ele")) o.getDouble("ele") else null
                    )
                )
            }
            byFolder.forEach { (folder, pts) -> addPoints(folder, pts, replace = false) }
            file.delete()
        } catch (e: Exception) {
            Log.e("Repo", "Could not move old points", e)
        }
    }
}
