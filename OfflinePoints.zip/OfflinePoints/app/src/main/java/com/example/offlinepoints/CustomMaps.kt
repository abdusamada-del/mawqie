package com.example.offlinepoints

import android.content.Context
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.MapTileIndex
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream

/**
 * One online map loaded from a Locus-style map file (providers.xml).
 * Zoom values here are already converted to normal tile zoom (0 = whole world).
 */
data class CustomMap(
    val id: String,
    val name: String,
    val url: String,
    val servers: List<String>,
    val zoomMin: Int,
    val zoomMax: Int,
    val tileSize: Int,
    val attribution: String,
    val headers: Map<String, String>,
    /** Provider name from the file, e.g. "Google" */
    val group: String = "User maps",
    /** Map style from the file, e.g. "Satellite" */
    val mode: String = ""
)

/**
 * Reads, stores and serves custom online maps.
 * The app contains no map addresses of its own: they come only from the file the user loads.
 */
object CustomMaps {

    private const val PREFS = "mawqie"
    private const val KEY = "customMaps"

    // ── Reading a Locus map file ─────────────────────────────────────────────

    fun parse(input: InputStream): List<CustomMap> {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(input, null)

        val result = ArrayList<CustomMap>()
        var inProvider = false
        var tag = ""
        var id = ""
        var name = ""
        var mode = ""
        var url = ""
        var serverPart = ""
        var zoomPart = ""
        var zoomMin: Int? = null
        var zoomMax: Int? = null
        var tileSize = 256
        var attribution = ""
        val headers = LinkedHashMap<String, String>()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    tag = parser.name.lowercase()
                    if (tag == "provider") {
                        inProvider = true
                        id = parser.getAttributeValue(null, "id")?.trim().orEmpty()
                        name = ""; mode = ""; url = ""; serverPart = ""; zoomPart = ""
                        zoomMin = null; zoomMax = null; tileSize = 256; attribution = ""
                        headers.clear()
                    }
                }

                XmlPullParser.TEXT -> if (inProvider) {
                    val t = parser.text?.trim().orEmpty()
                    if (t.isNotEmpty()) when (tag) {
                        "name" -> name = t
                        "mode" -> mode = t
                        "url" -> url = t
                        "serverpart" -> serverPart = t
                        "zoompart" -> zoomPart = t
                        "zoommin" -> zoomMin = t.toIntOrNull()
                        "zoommax" -> zoomMax = t.toIntOrNull()
                        "tilesize" -> tileSize = t.toIntOrNull() ?: 256
                        "attribution" -> attribution = t
                        "extraheader" -> {
                            val k = t.substringBefore('#').trim()
                            val v = t.substringAfter('#', "").trim()
                            if (k.isNotEmpty() && v.isNotEmpty()) headers[k] = v
                        }
                    }
                }

                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("provider", ignoreCase = true) && inProvider) {
                        inProvider = false
                        val cleanUrl = normalizeUrl(url)
                        if (cleanUrl.isNotEmpty()) {
                            // Locus numbers zoom levels from 8, written as zoomPart "{z}-8"
                            val offset = zoomOffset(zoomPart)
                            val zMin = ((zoomMin ?: offset) - offset).coerceIn(0, 22)
                            val zMax = ((zoomMax ?: (offset + 19)) - offset).coerceIn(zMin, 22)
                            val fullName = listOf(name, mode).filter { it.isNotBlank() }.joinToString(" ")
                                .ifBlank { "Custom map" }
                            val key = id.ifBlank { fullName }
                            result.add(
                                CustomMap(
                                    id = key,
                                    name = fullName,
                                    url = cleanUrl,
                                    servers = serverPart.split(';', ',').map { it.trim() }.filter { it.isNotEmpty() },
                                    zoomMin = zMin,
                                    zoomMax = zMax,
                                    tileSize = tileSize,
                                    attribution = attribution,
                                    headers = LinkedHashMap(headers),
                                    group = name.ifBlank { "User maps" },
                                    mode = mode.ifBlank { name.ifBlank { "Custom map" } }
                                )
                            )
                        }
                    }
                    tag = ""
                }
            }
            event = parser.next()
        }
        return result
    }

    /** "{z}-8" -> 8, "{z}+1" -> -1, "{z}" or empty -> 0 */
    private fun zoomOffset(zoomPart: String): Int {
        val m = Regex("""\{z\}\s*([+-])\s*(\d+)""").find(zoomPart) ?: return 0
        val n = m.groupValues[2].toInt()
        return if (m.groupValues[1] == "-") n else -n
    }

    /** Some Locus files write the address as "a" + {x} + "b"; turn that into one plain template. */
    private fun normalizeUrl(raw: String): String {
        var s = raw.trim()
        if (s.contains("\"")) {
            s = s.replace(Regex("\"\\s*\\+\\s*"), "")
                .replace(Regex("\\s*\\+\\s*\""), "")
                .replace("\"", "")
        }
        return s.trim()
    }

    // ── Saving ───────────────────────────────────────────────────────────────

    fun load(ctx: Context): List<CustomMap> {
        val json = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val s = o.getJSONArray("servers")
                val h = o.getJSONObject("headers")
                CustomMap(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    url = o.getString("url"),
                    servers = (0 until s.length()).map { s.getString(it) },
                    zoomMin = o.getInt("zoomMin"),
                    zoomMax = o.getInt("zoomMax"),
                    tileSize = o.getInt("tileSize"),
                    attribution = o.optString("attribution", ""),
                    headers = h.keys().asSequence().associateWith { h.getString(it) },
                    group = legacyGroup(o),
                    mode = legacyMode(o)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Maps added by older versions have no proper group: "Google Classic" was stored with
     * group "User maps". Split such names into group "Google" and style "Classic".
     */
    private fun isLegacy(o: JSONObject): Boolean {
        val g = o.optString("group", "")
        val m = o.optString("mode", "")
        return g.isBlank() || (g == "User maps" && (m.isBlank() || m == o.getString("name")))
    }

    private fun legacyGroup(o: JSONObject): String {
        if (!isLegacy(o)) return o.getString("group")
        val n = o.getString("name")
        return if (n.contains(' ')) n.substringBefore(' ') else "User maps"
    }

    private fun legacyMode(o: JSONObject): String {
        if (!isLegacy(o)) return o.optString("mode", "").ifBlank { o.getString("name") }
        val n = o.getString("name")
        return if (n.contains(' ')) n.substringAfter(' ') else n
    }

    private fun save(ctx: Context, list: List<CustomMap>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("name", m.name)
                    .put("url", m.url)
                    .put("servers", JSONArray(m.servers))
                    .put("zoomMin", m.zoomMin)
                    .put("zoomMax", m.zoomMax)
                    .put("tileSize", m.tileSize)
                    .put("attribution", m.attribution)
                    .put("headers", JSONObject(m.headers as Map<*, *>))
                    .put("group", m.group)
                    .put("mode", m.mode)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    /** Adds maps; a map with the same id as an existing one replaces it. */
    fun add(ctx: Context, maps: List<CustomMap>) {
        val ids = maps.map { it.id }.toSet()
        save(ctx, load(ctx).filter { it.id !in ids } + maps)
    }

    fun remove(ctx: Context, id: String) {
        save(ctx, load(ctx).filter { it.id != id })
    }

    // ── Map tiles ────────────────────────────────────────────────────────────

    /** Name used for this map's tiles in the cache. */
    fun cacheName(m: CustomMap): String = "custom_" + m.id.replace(Regex("[^A-Za-z0-9_]"), "_")

    fun tileSource(m: CustomMap): OnlineTileSourceBase = object : OnlineTileSourceBase(
        cacheName(m),
        m.zoomMin,
        m.zoomMax,
        m.tileSize,
        ".png",
        arrayOf(m.url),
        m.attribution
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            val z = MapTileIndex.getZoom(pMapTileIndex)
            val server = if (m.servers.isEmpty()) "" else m.servers[(x + y) % m.servers.size]
            return m.url
                .replace("{x}", x.toString())
                .replace("{y}", y.toString())
                .replace("{z}", z.toString())
                .replace("{s}", server)
                .replace("{quadkey}", quadKey(x, y, z))
        }
    }

    private fun quadKey(x: Int, y: Int, z: Int): String {
        val sb = StringBuilder()
        for (i in z downTo 1) {
            var digit = 0
            val mask = 1 shl (i - 1)
            if (x and mask != 0) digit += 1
            if (y and mask != 0) digit += 2
            sb.append(digit)
        }
        return sb.toString()
    }
}
