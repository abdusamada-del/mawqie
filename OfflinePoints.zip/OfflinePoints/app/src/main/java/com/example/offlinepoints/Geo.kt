package com.example.offlinepoints

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object Geo {

    private val result = FloatArray(2)

    @Synchronized
    fun distance(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double): Float {
        Location.distanceBetween(fromLat, fromLon, toLat, toLon, result)
        return result[0]
    }

    /** Compass bearing (0 = north) from the first place to the second. */
    @Synchronized
    fun bearing(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double): Float {
        Location.distanceBetween(fromLat, fromLon, toLat, toLon, result)
        return result[1]
    }

    fun formatDistance(m: Float): String = when {
        m < 1000 -> String.format(Locale.US, "%.0f m", m)
        m < 100_000 -> String.format(Locale.US, "%.1f km", m / 1000)
        else -> String.format(Locale.US, "%.0f km", m / 1000)
    }

    /** Your last GPS position if known, otherwise the map center. */
    @SuppressLint("MissingPermission")
    fun referenceLocation(ctx: Context): Pair<Double, Double> {
        val la = AppState.lastFixLat
        val lo = AppState.lastFixLon
        if (la != null && lo != null) return la to lo
        val granted =
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        if (granted) {
            try {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val best = lm.getProviders(true)
                    .mapNotNull { lm.getLastKnownLocation(it) }
                    .maxByOrNull { it.time }
                if (best != null) return best.latitude to best.longitude
            } catch (e: Exception) {
                // fall through to map center
            }
        }
        return AppState.mapCenterLat to AppState.mapCenterLon
    }

    private val dateFormat = SimpleDateFormat("d MMM yyyy", Locale.US)
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    fun formatDate(ms: Long): String =
        if (ms <= 0) "" else synchronized(dateFormat) { dateFormat.format(Date(ms)) }

    /** "2026-10-13T08:15:00Z" -> milliseconds, or null. */
    fun parseIsoTime(s: String): Long? {
        val t = s.trim()
        if (t.length < 19) return null
        return try {
            synchronized(isoFormat) { isoFormat.parse(t.substring(0, 19))?.time }
        } catch (e: Exception) {
            null
        }
    }

    fun isoTime(ms: Long): String = synchronized(isoFormat) { isoFormat.format(Date(ms)) } + "Z"
}
