package com.example.offlinepoints

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.api.IGeoPoint
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.ScaleBarOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import org.osmdroid.views.overlay.simplefastpoint.LabelledGeoPoint
import org.osmdroid.views.overlay.simplefastpoint.SimpleFastPointOverlay
import org.osmdroid.views.overlay.simplefastpoint.SimpleFastPointOverlayOptions
import org.osmdroid.views.overlay.simplefastpoint.SimplePointTheme
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var tvCenter: TextView
    private lateinit var tvFilter: TextView
    private lateinit var progress: ProgressBar
    private lateinit var card: View
    private lateinit var tvName: TextView
    private lateinit var tvInfo: TextView

    private var pointsOverlay: SimpleFastPointOverlay? = null
    private var locationOverlay: MyLocationNewOverlay? = null
    private var selected: GpxPoint? = null
    private var satellite = false

    /** null = show every folder on the map */
    private var visibleFolder: String? = null

    // ── Screens & pickers ────────────────────────────────────────────────────

    private val pickGpx =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) askFolderAndImport(uri)
        }

    private val libraryScreen =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                visibleFolder = result.data?.getStringExtra(LibraryActivity.EXTRA_FOLDER)
                reloadPoints(fit = true)
            } else {
                reloadPoints(fit = false) // a folder may have been deleted
            }
        }

    private val searchScreen =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                openFoundPoint(
                    data.getDoubleExtra(SearchActivity.EXTRA_LAT, 0.0),
                    data.getDoubleExtra(SearchActivity.EXTRA_LON, 0.0),
                    data.getStringExtra(SearchActivity.EXTRA_NAME).orEmpty()
                )
            }
        }

    private val askLocation =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
            if (granted.values.any { it }) enableLocation()
        }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // osmdroid setup: tile cache settings + required user agent for OpenStreetMap
        Configuration.getInstance().load(
            applicationContext,
            getSharedPreferences("osmdroid", MODE_PRIVATE)
        )
        Configuration.getInstance().userAgentValue = packageName

        setContentView(R.layout.activity_main)

        map = findViewById(R.id.map)
        tvCenter = findViewById(R.id.tvCenter)
        tvFilter = findViewById(R.id.tvFilter)
        progress = findViewById(R.id.progress)
        card = findViewById(R.id.card)
        tvName = findViewById(R.id.tvName)
        tvInfo = findViewById(R.id.tvInfo)

        setupMap()
        setupButtons()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (card.visibility == View.VISIBLE) {
                    hideCard()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        reloadPoints(fit = true)

        // Opened by tapping a .gpx file in a file manager
        if (savedInstanceState == null && intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { askFolderAndImport(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        if (hasLocationPermission()) locationOverlay?.enableMyLocation()
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        locationOverlay?.disableMyLocation()
    }

    // ── Map ──────────────────────────────────────────────────────────────────

    private fun setupMap() {
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.minZoomLevel = 3.0
        map.controller.setZoom(12.0)
        map.controller.setCenter(GeoPoint(25.2048, 55.2708)) // Dubai, until points are loaded

        map.overlays.add(ScaleBarOverlay(map).apply { setAlignBottom(true) })
        map.overlays.add(CopyrightOverlay(this))

        map.addMapListener(object : MapListener {
            override fun onScroll(event: ScrollEvent?): Boolean {
                updateCenterText(); return false
            }

            override fun onZoom(event: ZoomEvent?): Boolean {
                updateCenterText(); return false
            }
        })
        updateCenterText()
    }

    private fun updateCenterText() {
        val c: IGeoPoint = map.mapCenter
        tvCenter.text = String.format(Locale.US, "%.5f, %.5f", c.latitude, c.longitude)
    }

    private fun toggleLayer() {
        satellite = !satellite
        map.setTileSource(if (satellite) TileSources.SATELLITE else TileSourceFactory.MAPNIK)
        toast(if (satellite) "Satellite map" else "Street map")
    }

    // ── Points on the map ────────────────────────────────────────────────────

    private fun reloadPoints(fit: Boolean) {
        lifecycleScope.launch {
            val all = withContext(Dispatchers.IO) { PointStore.all(this@MainActivity) }
            var pts = if (visibleFolder == null) all else all.filter { it.folder == visibleFolder }
            if (pts.isEmpty() && visibleFolder != null) {
                visibleFolder = null
                pts = all
            }
            showPoints(pts, fit)
        }
    }

    private fun showPoints(pts: List<GpxPoint>, fit: Boolean) {
        pointsOverlay?.let { map.overlays.remove(it) }
        pointsOverlay = null

        tvFilter.text = when {
            pts.isEmpty() -> "No points yet. Tap the import button below."
            visibleFolder == null -> "All points: ${pts.size}"
            else -> "Folder: $visibleFolder (${pts.size})   Show all"
        }

        if (pts.isNotEmpty()) {
            val density = resources.displayMetrics.density

            val pointPaint = Paint().apply {
                color = Color.rgb(213, 0, 0)
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            val labelPaint = Paint().apply {
                color = Color.BLACK
                textSize = 13 * density
                textAlign = Paint.Align.CENTER
                isFakeBoldText = true
                isAntiAlias = true
                setShadowLayer(4f, 0f, 0f, Color.WHITE) // white halo, readable on satellite
            }

            val geoPoints = pts.map { LabelledGeoPoint(it.lat, it.lon, it.label) }
            @Suppress("DEPRECATION")
            val theme = SimplePointTheme(geoPoints, true)

            val options = SimpleFastPointOverlayOptions.getDefaultStyle()
                .setAlgorithm(SimpleFastPointOverlayOptions.RenderingAlgorithm.MEDIUM_OPTIMIZATION)
                .setSymbol(SimpleFastPointOverlayOptions.Shape.CIRCLE)
                .setRadius(5 * density)
                .setPointStyle(pointPaint)
                .setTextStyle(labelPaint)
                .setMinZoomShowLabels(14)
                .setCellSize(12)
                .setIsClickable(true)

            val overlay = SimpleFastPointOverlay(theme, options)
            val shown = pts
            overlay.setOnClickListener { _, index -> showCard(shown[index]) }

            map.overlays.add(overlay)
            pointsOverlay = overlay

            if (fit) fitTo(pts)
        }
        map.invalidate()
    }

    private fun fitTo(pts: List<GpxPoint>) {
        if (pts.size == 1) {
            map.controller.animateTo(GeoPoint(pts[0].lat, pts[0].lon), 16.0, 800L)
            return
        }
        val box = BoundingBox.fromGeoPoints(pts.map { GeoPoint(it.lat, it.lon) })
        map.post { map.zoomToBoundingBox(box.increaseByScale(1.2f), true, 80) }
    }

    private fun openFoundPoint(lat: Double, lon: Double, name: String) {
        val p = PointStore.all(this).firstOrNull { it.lat == lat && it.lon == lon && it.name == name }
            ?: GpxPoint(lat, lon, name)
        if (visibleFolder != null && visibleFolder != p.folder) {
            visibleFolder = null
            reloadPoints(fit = false)
        }
        map.controller.animateTo(GeoPoint(lat, lon), 17.0, 800L)
        showCard(p)
    }

    // ── Point card ───────────────────────────────────────────────────────────

    private fun showCard(p: GpxPoint) {
        selected = p
        tvName.text = p.label
        tvInfo.text = buildString {
            append(p.coords)
            p.ele?.let { append(String.format(Locale.US, "   %.0f m", it)) }
            append("\nFolder: ").append(p.folder)
            if (p.desc.isNotBlank()) append("\n").append(p.desc)
        }
        card.visibility = View.VISIBLE
    }

    private fun hideCard() {
        card.visibility = View.GONE
        selected = null
    }

    private fun navigateToSelected() {
        val p = selected ?: return
        val uri = Uri.parse("geo:${p.lat},${p.lon}?q=${p.lat},${p.lon}(${Uri.encode(p.label)})")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            toast("No navigation app installed")
        }
    }

    private fun copySelected() {
        val p = selected ?: return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("coordinates", "${p.lat}, ${p.lon}"))
        toast("Coordinates copied")
    }

    // ── Buttons ──────────────────────────────────────────────────────────────

    private fun setupButtons() {
        findViewById<View>(R.id.btnLibrary).setOnClickListener {
            libraryScreen.launch(Intent(this, LibraryActivity::class.java))
        }
        findViewById<View>(R.id.btnSearch).setOnClickListener {
            val c = map.mapCenter
            searchScreen.launch(
                Intent(this, SearchActivity::class.java)
                    .putExtra(SearchActivity.EXTRA_CENTER_LAT, c.latitude)
                    .putExtra(SearchActivity.EXTRA_CENTER_LON, c.longitude)
            )
        }
        findViewById<View>(R.id.btnLayers).setOnClickListener { toggleLayer() }
        findViewById<View>(R.id.btnMyLocation).setOnClickListener { onMyLocationClicked() }
        findViewById<View>(R.id.btnZoomIn).setOnClickListener { map.controller.zoomIn() }
        findViewById<View>(R.id.btnZoomOut).setOnClickListener { map.controller.zoomOut() }
        findViewById<View>(R.id.btnImport).setOnClickListener { pickGpx.launch(arrayOf("*/*")) }
        findViewById<View>(R.id.btnCloseCard).setOnClickListener { hideCard() }
        findViewById<View>(R.id.btnNavigate).setOnClickListener { navigateToSelected() }
        findViewById<View>(R.id.btnCopy).setOnClickListener { copySelected() }
        tvFilter.setOnClickListener {
            if (visibleFolder != null) {
                visibleFolder = null
                reloadPoints(fit = true)
            }
        }
    }

    // ── My location ──────────────────────────────────────────────────────────

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun onMyLocationClicked() {
        if (!hasLocationPermission()) {
            askLocation.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
            return
        }
        val here = locationOverlay?.myLocation
        if (here != null) {
            map.controller.animateTo(here, 17.0, 800L)
        } else {
            enableLocation()
            toast("Waiting for GPS…")
        }
    }

    private fun enableLocation() {
        val overlay = locationOverlay ?: MyLocationNewOverlay(GpsMyLocationProvider(this), map).also {
            map.overlays.add(it)
            locationOverlay = it
        }
        overlay.enableMyLocation()
        overlay.runOnFirstFix {
            runOnUiThread { overlay.myLocation?.let { map.controller.animateTo(it, 17.0, 800L) } }
        }
    }

    // ── Import ───────────────────────────────────────────────────────────────

    private fun askFolderAndImport(uri: Uri) {
        val suggested = fileName(uri)?.substringBeforeLast('.')?.takeIf { it.isNotBlank() } ?: "Imported"
        val input = EditText(this).apply {
            setText(suggested)
            setSelectAllOnFocus(true)
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Import into folder")
            .setMessage("If a folder with this name exists, its points are replaced.")
            .setView(box)
            .setPositiveButton("Import") { _, _ ->
                importGpx(uri, input.text.toString().trim().ifEmpty { suggested })
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun importGpx(uri: Uri, folder: String) {
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val pts = contentResolver.openInputStream(uri)?.use { GpxParser.parse(it, folder) }
                        ?: error("Cannot open the file")
                    if (pts.isNotEmpty()) PointStore.replaceFolder(this@MainActivity, folder, pts)
                    pts.size
                }
            }
            progress.visibility = View.GONE
            result.onSuccess { count ->
                if (count == 0) {
                    toast("No points found in this file")
                } else {
                    toast("Imported $count points into \"$folder\"")
                    visibleFolder = null
                    reloadPoints(fit = true)
                }
            }.onFailure {
                toast("Import failed: ${it.message}")
            }
        }
    }

    private fun fileName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
