package com.example.offlinepoints

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.view.MotionEvent
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.ScaleBarOverlay
import org.osmdroid.views.overlay.gestures.RotationGestureOverlay
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var tvCenter: TextView
    private lateinit var tvFilter: TextView
    private lateinit var card: View
    private lateinit var tvName: TextView
    private lateinit var tvInfo: TextView
    private lateinit var btnToggleAll: ImageButton
    private lateinit var pointsOverlay: PointsOverlay

    private lateinit var position: PositionOverlay
    private lateinit var btnGps: ImageButton
    private lateinit var tvSpeed: TextView
    private lateinit var ivCompass: ImageView
    private lateinit var rotationGestures: RotationGestureOverlay
    private var centerOnNextFix = false

    /** Follow mode: the map keeps your position in the middle while you move (like Locus). */
    private var following = false
    private lateinit var btnMyLocation: View
    private var myLocationBg: android.graphics.drawable.Drawable? = null
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var multiTouch = false
    private var selected: GpxPoint? = null
    /** "esri_street", "esri_sat", "osm" or "custom:<id>" */
    private var mapSource = "esri_street"
    private var firstLoad = true
    private var fitAfterLoad = false
    private val prefs by lazy { getSharedPreferences("mawqie", MODE_PRIVATE) }

    private val pickGpx =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) askFolderAndImport(uri)
        }

    private val askLocation =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
            if (granted.values.any { it }) enableLocation()
        }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue =
            "Mawqie/3.4 (Android; +https://github.com/abdusamada-del/mawqie)" // OpenStreetMap asks for app name + contact
        setContentView(R.layout.activity_main)
        Repo.init(this)

        map = findViewById(R.id.map)
        tvCenter = findViewById(R.id.tvCenter)
        tvFilter = findViewById(R.id.tvFilter)
        card = findViewById(R.id.card)
        tvName = findViewById(R.id.tvName)
        tvInfo = findViewById(R.id.tvInfo)
        btnToggleAll = findViewById(R.id.btnToggleAll)
        btnGps = findViewById(R.id.btnGps)
        btnMyLocation = findViewById(R.id.btnMyLocation)
        myLocationBg = btnMyLocation.background
        tvSpeed = findViewById(R.id.tvSpeed)
        ivCompass = findViewById(R.id.ivCompass)

        mapSource = prefs.getString("mapSource", null)
            ?: if (prefs.getBoolean("satellite", false)) "esri_sat" else "esri_street"
        setupMap()
        watchMapDrags()
        setupButtons()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (card.visibility == View.VISIBLE) {
                    hideCard()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        updateGpsIcon()
        if (savedInstanceState == null && !hasLocationPermission() && !prefs.getBoolean("askedLocation", false)) {
            prefs.edit().putBoolean("askedLocation", true).apply()
            askLocation.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }

        if (savedInstanceState == null && intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { askFolderAndImport(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        if (hasLocationPermission()) position.start()
        map.post(gpsStatusTicker)
        if (prefs.getBoolean("mapsChanged", false)) {
            // chosen, cleared or changed on the Maps screen
            prefs.edit().putBoolean("mapsChanged", false).apply()
            applyMapSource(prefs.getString("mapSource", "esri_street") ?: "esri_street")
        }
        reloadPoints()
    }

    override fun onPause() {
        super.onPause()
        saveMapState()
        map.onPause()
        position.stop()
        map.removeCallbacks(gpsStatusTicker)
    }

    /** Re-checks the GPS icon every few seconds (a fix can go stale without any callback). */
    private val gpsStatusTicker = object : Runnable {
        override fun run() {
            updateGpsIcon()
            map.invalidate()
            map.postDelayed(this, 3000L)
        }
    }

    private fun saveMapState() {
        val c = map.mapCenter
        AppState.mapCenterLat = c.latitude
        AppState.mapCenterLon = c.longitude
        position.myLocation?.let {
            AppState.lastFixLat = it.latitude
            AppState.lastFixLon = it.longitude
        }
        prefs.edit()
            .putString("lat", c.latitude.toString())
            .putString("lon", c.longitude.toString())
            .putFloat("zoom", map.zoomLevelDouble.toFloat())
            .putFloat("orientation", map.mapOrientation)
            .apply()
    }

    // ── Map ──────────────────────────────────────────────────────────────────

    private fun setupMap() {
        applyMapSource(mapSource)
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.minZoomLevel = 3.0
        map.maxZoomLevel = 20.0

        val savedLat = prefs.getString("lat", null)?.toDoubleOrNull()
        val savedLon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (savedLat != null && savedLon != null) {
            map.controller.setZoom(prefs.getFloat("zoom", 12f).toDouble())
            map.controller.setCenter(GeoPoint(savedLat, savedLon))
        } else {
            map.controller.setZoom(12.0)
            map.controller.setCenter(GeoPoint(25.2048, 55.2708)) // Dubai
        }

        map.overlays.add(ScaleBarOverlay(map).apply { setAlignBottom(true) })
        map.overlays.add(CopyrightOverlay(this))

        pointsOverlay = PointsOverlay(
            this,
            onTap = { id -> openPoint(id, moveMap = false) },
            myLocation = { position.myLocation }
        )
        map.overlays.add(pointsOverlay)

        position = PositionOverlay(this) { onLocationUpdate() }
        map.overlays.add(position)

        // Two-finger rotation, and a small compass that shows while the map is turned.
        rotationGestures = RotationGestureOverlay(map)
        rotationGestures.isEnabled = prefs.getBoolean("rotation", true)
        map.overlays.add(rotationGestures)
        map.mapOrientation = prefs.getFloat("orientation", 0f)
        map.overlays.add(object : Overlay() {
            override fun draw(c: Canvas, mapView: MapView, shadow: Boolean) {
                if (!shadow) updateCompass()
            }
        })

        map.addMapListener(object : MapListener {
            override fun onScroll(event: ScrollEvent?): Boolean {
                updateCenterText(); return false
            }

            override fun onZoom(event: ZoomEvent?): Boolean {
                updateCenterText(); return false
            }
        })
        updateCenterText()
    }

    private fun updateCenterText() {
        val c = map.mapCenter
        AppState.mapCenterLat = c.latitude
        AppState.mapCenterLon = c.longitude
        tvCenter.text = String.format(Locale.US, "%.5f, %.5f", c.latitude, c.longitude)
    }

    private fun openMyPoints() {
        startActivity(Intent(this, LibraryActivity::class.java))
    }

    private fun showMainMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "My points")
        pm.menu.add(0, 2, 1, "Import GPX file")
        pm.menu.add(0, 3, 2, "Rotate map with two fingers").apply {
            isCheckable = true
            isChecked = rotationGestures.isEnabled
        }
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> openMyPoints()
                2 -> pickGpx.launch(arrayOf("*/*"))
                3 -> setRotationEnabled(!rotationGestures.isEnabled)
            }
            true
        }
        pm.show()
    }

    private fun setRotationEnabled(on: Boolean) {
        rotationGestures.isEnabled = on
        prefs.edit().putBoolean("rotation", on).apply()
        if (!on) resetNorth()
        toast(if (on) "Map rotation on: turn the map with two fingers" else "Map rotation off: north is always up")
    }

    /** Compass is shown only while the map is turned; its red tip points north. */
    private fun updateCompass() {
        val angle = ((map.mapOrientation % 360f) + 360f) % 360f
        val turned = angle > 0.5f && angle < 359.5f
        val want = if (turned) View.VISIBLE else View.GONE
        if (ivCompass.visibility != want) ivCompass.visibility = want
        if (turned) ivCompass.rotation = map.mapOrientation
    }

    private fun resetNorth() {
        map.mapOrientation = 0f
        updateCompass()
        map.invalidate()
    }

    /** Quick map selection: your visible maps, plus the full Maps screen. */
    private fun showMapMenu(anchor: View) {
        val entries = MapRegistry.all(this).filter { !MapRegistry.isHidden(this, it.key) || it.key == mapSource }
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        entries.forEachIndexed { i, e -> m.add(1, 100 + i, i, e.fullTitle) }
        m.setGroupCheckable(1, true, true)
        val cur = entries.indexOfFirst { it.key == mapSource }
        if (cur >= 0) m.findItem(100 + cur)?.isChecked = true
        m.add(2, 1, 1000, "Manage maps…")
        pm.setOnMenuItemClickListener { item ->
            if (item.itemId == 1) {
                startActivity(Intent(this, MapsActivity::class.java))
            } else {
                entries.getOrNull(item.itemId - 100)?.let { applyMapSource(it.key) }
            }
            true
        }
        pm.show()
    }

    private fun applyMapSource(key: String) {
        val entry = MapRegistry.find(this, key) ?: MapRegistry.find(this, "esri_street") ?: return
        val cfg = Configuration.getInstance()
        // Extra request headers and cache timeout belong to the map in use only
        val extra = cfg.additionalHttpRequestProperties
        extra.clear()
        entry.headers.forEach { (k, v) -> extra[k] = v }
        cfg.expirationOverrideDuration = MapRegistry.timeoutMs(this, entry.key)
        map.setTileSource(entry.source())
        mapSource = entry.key
        prefs.edit().putString("mapSource", mapSource).apply()
        map.invalidate()
    }

    // ── Points ───────────────────────────────────────────────────────────────

    private fun reloadPoints() {
        lifecycleScope.launch {
            val data = withContext(Dispatchers.IO) {
                Repo.visiblePoints() to Repo.folders().associateBy { it.name }
            }
            val showAll = prefs.getBoolean("showAll", true)
            pointsOverlay.setData(data.first, data.second, showAll)
            updateToggle(showAll, data.first.size)

            val focus = AppState.focusPointId
            if (focus >= 0) {
                AppState.focusPointId = -1
                openPoint(focus, moveMap = true)
            } else {
                selected?.let { openPoint(it.id, moveMap = false) } // refresh, it may have changed
                val noSavedPlace = prefs.getString("lat", null) == null
                if ((fitAfterLoad || (firstLoad && noSavedPlace)) && data.first.isNotEmpty()) fitTo(data.first)
            }
            fitAfterLoad = false
            firstLoad = false
            map.invalidate()
        }
    }

    private fun fitTo(pts: List<MapPoint>) {
        if (pts.size == 1) {
            map.controller.animateTo(GeoPoint(pts[0].lat, pts[0].lon), 16.0, 800L)
            return
        }
        val box = BoundingBox.fromGeoPoints(pts.map { GeoPoint(it.lat, it.lon) })
        map.post { map.zoomToBoundingBox(box.increaseByScale(1.2f), true, 80) }
    }

    private fun openPoint(id: Long, moveMap: Boolean) {
        lifecycleScope.launch {
            val p = withContext(Dispatchers.IO) { Repo.point(id) }
            if (p == null) {
                hideCard()
                return@launch
            }
            selected = p
            pointsOverlay.selected = MapPoint.from(p)
            if (moveMap) map.controller.animateTo(GeoPoint(p.lat, p.lon), max(map.zoomLevelDouble, 17.0), 800L)
            showCard(p)
            map.invalidate()
        }
    }

    private fun updateToggle(showAll: Boolean, count: Int) {
        btnToggleAll.setImageResource(if (showAll) R.drawable.ic_eye else R.drawable.ic_eye_off)
        tvFilter.text = if (showAll) "Points on map: $count" else "All points hidden"
    }

    private fun toggleAllPoints() {
        val show = !prefs.getBoolean("showAll", true)
        prefs.edit().putBoolean("showAll", show).apply()
        pointsOverlay.showAll = show
        updateToggle(show, pointsOverlay.points.size)
        map.invalidate()
        toast(if (show) "Points shown" else "All points hidden")
    }

    // ── Point card ───────────────────────────────────────────────────────────

    private fun showCard(p: GpxPoint) {
        tvName.text = p.label
        tvInfo.text = buildString {
            append(p.coords)
            p.ele?.let { append(String.format(Locale.US, "   %.0f m", it)) }
            append("\nFolder: ").append(p.folder)
            if (p.created > 0) append("\nCreated: ").append(Geo.formatDate(p.created))
            if (p.desc.isNotBlank()) append("\n").append(p.desc)
        }
        updateCardEye(p.visible)
        card.visibility = View.VISIBLE
    }

    private fun updateCardEye(visible: Boolean) {
        val eye = findViewById<ImageButton>(R.id.btnCardEye)
        eye.setImageResource(if (visible) R.drawable.ic_eye else R.drawable.ic_eye_off_row)
        eye.setBackgroundResource(if (visible) R.drawable.bg_eye_on else 0)
    }

    /** Eye on the point card: keep the point shown on the map, or hide it. */
    private fun toggleSelectedVisible() {
        val p = selected ?: return
        val nowOn = !p.visible
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { Repo.setVisible(p.id, nowOn) }
            selected = p.copy(visible = nowOn)
            updateCardEye(nowOn)
            toast(if (nowOn) "${p.label} is now shown on the map" else "${p.label} is hidden")
            reloadPoints()
        }
    }

    private fun hideCard() {
        card.visibility = View.GONE
        selected = null
        pointsOverlay.selected = null
        map.invalidate()
    }

    private fun navigateToSelected() {
        val p = selected ?: return
        val uri = Uri.parse("geo:${p.lat},${p.lon}?q=${p.lat},${p.lon}(${Uri.encode(p.label)})")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            toast("No navigation app installed")
        }
    }

    /** Shares the point's name, coordinates and a Google Maps link with any app (WhatsApp, SMS, email…). */
    private fun shareSelected() {
        val p = selected ?: return
        val ll = String.format(Locale.US, "%.6f,%.6f", p.lat, p.lon)
        val message = "${p.label}\n${p.coords}\nhttps://maps.google.com/?q=$ll"
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
        }
        startActivity(Intent.createChooser(send, "Share ${p.label}"))
    }

    /** Opens Google Street View at the point (official Google Maps link). */
    private fun openStreetView() {
        val p = selected ?: return
        val ll = String.format(Locale.US, "%.6f,%.6f", p.lat, p.lon)
        val uri = Uri.parse("https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=$ll")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            toast("No app found to open Street View")
        }
    }

    private fun copySelected() {
        val p = selected ?: return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("coordinates", "${p.lat}, ${p.lon}"))
        toast("Coordinates copied")
    }

    // ── Buttons ──────────────────────────────────────────────────────────────

    private fun setupButtons() {
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMainMenu(it) }
        findViewById<View>(R.id.btnMyPoints).setOnClickListener { openMyPoints() }
        findViewById<View>(R.id.btnSearch).setOnClickListener {
            saveMapState()
            startActivity(Intent(this, SearchActivity::class.java))
        }
        btnToggleAll.setOnClickListener { toggleAllPoints() }
        findViewById<View>(R.id.btnLayers).setOnClickListener { showMapMenu(it) }
        findViewById<View>(R.id.btnMyLocation).setOnClickListener { onMyLocationClicked() }
        btnGps.setOnClickListener { onMyLocationClicked() }
        ivCompass.setOnClickListener { resetNorth() }
        findViewById<View>(R.id.btnZoomIn).setOnClickListener { map.controller.zoomIn() }
        findViewById<View>(R.id.btnZoomOut).setOnClickListener { map.controller.zoomOut() }
        findViewById<View>(R.id.btnCloseCard).setOnClickListener { hideCard() }
        findViewById<View>(R.id.btnCardEye).setOnClickListener { toggleSelectedVisible() }
        findViewById<View>(R.id.btnNavigate).setOnClickListener { navigateToSelected() }
        findViewById<View>(R.id.btnCopy).setOnClickListener { copySelected() }
        findViewById<View>(R.id.btnShare).setOnClickListener { shareSelected() }
        findViewById<View>(R.id.btnStreetView).setOnClickListener { openStreetView() }
    }

    // ── My location ──────────────────────────────────────────────────────────

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun onMyLocationClicked() {
        if (!hasLocationPermission()) {
            askLocation.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
            return
        }
        position.start()
        setFollowing(true)
        val here = position.myLocation
        if (here != null) {
            map.controller.animateTo(here, max(map.zoomLevelDouble, 17.0), 800L)
        } else {
            centerOnNextFix = true
            toast("Waiting for GPS…")
        }
    }

    /** Called after the user allows location access. */
    private fun enableLocation() {
        centerOnNextFix = true
        setFollowing(true)
        position.start()
        updateGpsIcon()
    }

    private fun setFollowing(on: Boolean) {
        following = on
        if (on) btnMyLocation.setBackgroundColor(0xFF1E76D0.toInt()) else btnMyLocation.background = myLocationBg
    }

    /** One-finger drag stops follow mode; pinch-zoom and the +/- buttons keep it. */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun watchMapDrags() {
        val slop = 12 * resources.displayMetrics.density
        map.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    touchDownX = e.x
                    touchDownY = e.y
                    multiTouch = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> multiTouch = true
                MotionEvent.ACTION_MOVE -> {
                    if (following && !multiTouch && e.pointerCount == 1 &&
                        hypot(e.x - touchDownX, e.y - touchDownY) > slop
                    ) {
                        setFollowing(false)
                    }
                }
            }
            false // let the map handle the touch as usual
        }
    }

    private fun onLocationUpdate() {
        updateGpsIcon()
        if (following && !centerOnNextFix) {
            position.myLocation?.let { map.controller.animateTo(it) }
        }
        if (centerOnNextFix) {
            position.myLocation?.let {
                centerOnNextFix = false
                map.controller.animateTo(it, max(map.zoomLevelDouble, 17.0), 800L)
            }
        }
        map.invalidate()
    }

    /** Big speed number with a small "Km/hr" (same size as the top-bar coordinates). */
    private fun speedText(number: String): CharSequence {
        val unit = " Km/hr"
        val text = SpannableString(number + unit)
        text.setSpan(AbsoluteSizeSpan(12, true), number.length, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return text
    }

    /** Green dish = GPS fix available, grey = no GPS. Also refreshes the speed in the bottom bar. */
    private fun updateGpsIcon() {
        btnGps.setImageResource(if (position.hasGpsFix) R.drawable.ic_gps_on else R.drawable.ic_gps_off)
        val loc = position.location
        val number = if (position.hasGpsFix && loc != null && loc.hasSpeed()) {
            (loc.speed * 3.6f).roundToInt().toString()
        } else {
            "--"
        }
        tvSpeed.text = speedText(number)
    }

    // ── Import ───────────────────────────────────────────────────────────────

    private fun askFolderAndImport(uri: Uri) {
        Dialogs.importGpx(this, uri) { _, _ ->
            fitAfterLoad = true
            reloadPoints()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
