package com.example.offlinepoints

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.ScaleBarOverlay
import java.util.Locale
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var tvCenter: TextView
    private lateinit var tvFilter: TextView
    private lateinit var card: View
    private lateinit var tvName: TextView
    private lateinit var tvInfo: TextView
    private lateinit var btnToggleAll: ImageButton
    private lateinit var pointsOverlay: PointsOverlay

    private lateinit var position: PositionOverlay
    private lateinit var btnGps: ImageButton
    private var centerOnNextFix = false
    private var selected: GpxPoint? = null
    private var satellite = false
    private var firstLoad = true
    private var fitAfterLoad = false
    private val prefs by lazy { getSharedPreferences("mawqie", MODE_PRIVATE) }

    private val pickGpx =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) askFolderAndImport(uri)
        }

    private val askLocation =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
            if (granted.values.any { it }) enableLocation()
        }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = "Mawqie/2.0 (Android)"
        setContentView(R.layout.activity_main)
        Repo.init(this)

        map = findViewById(R.id.map)
        tvCenter = findViewById(R.id.tvCenter)
        tvFilter = findViewById(R.id.tvFilter)
        card = findViewById(R.id.card)
        tvName = findViewById(R.id.tvName)
        tvInfo = findViewById(R.id.tvInfo)
        btnToggleAll = findViewById(R.id.btnToggleAll)
        btnGps = findViewById(R.id.btnGps)

        satellite = prefs.getBoolean("satellite", false)
        setupMap()
        setupButtons()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (card.visibility == View.VISIBLE) {
                    hideCard()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        updateGpsIcon()
        if (savedInstanceState == null && !hasLocationPermission() && !prefs.getBoolean("askedLocation", false)) {
            prefs.edit().putBoolean("askedLocation", true).apply()
            askLocation.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }

        if (savedInstanceState == null && intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { askFolderAndImport(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        if (hasLocationPermission()) position.start()
        map.post(gpsStatusTicker)
        reloadPoints()
    }

    override fun onPause() {
        super.onPause()
        saveMapState()
        map.onPause()
        position.stop()
        map.removeCallbacks(gpsStatusTicker)
    }

    /** Re-checks the GPS icon every few seconds (a fix can go stale without any callback). */
    private val gpsStatusTicker = object : Runnable {
        override fun run() {
            updateGpsIcon()
            map.invalidate()
            map.postDelayed(this, 3000L)
        }
    }

    private fun saveMapState() {
        val c = map.mapCenter
        AppState.mapCenterLat = c.latitude
        AppState.mapCenterLon = c.longitude
        position.myLocation?.let {
            AppState.lastFixLat = it.latitude
            AppState.lastFixLon = it.longitude
        }
        prefs.edit()
            .putString("lat", c.latitude.toString())
            .putString("lon", c.longitude.toString())
            .putFloat("zoom", map.zoomLevelDouble.toFloat())
            .apply()
    }

    // ── Map ──────────────────────────────────────────────────────────────────

    private fun setupMap() {
        map.setTileSource(if (satellite) TileSources.SATELLITE else TileSources.STREET)
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.minZoomLevel = 3.0
        map.maxZoomLevel = 20.0

        val savedLat = prefs.getString("lat", null)?.toDoubleOrNull()
        val savedLon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (savedLat != null && savedLon != null) {
            map.controller.setZoom(prefs.getFloat("zoom", 12f).toDouble())
            map.controller.setCenter(GeoPoint(savedLat, savedLon))
        } else {
            map.controller.setZoom(12.0)
            map.controller.setCenter(GeoPoint(25.2048, 55.2708)) // Dubai
        }

        map.overlays.add(ScaleBarOverlay(map).apply { setAlignBottom(true) })
        map.overlays.add(CopyrightOverlay(this))

        pointsOverlay = PointsOverlay(
            this,
            onTap = { id -> openPoint(id, moveMap = false) },
            myLocation = { position.myLocation }
        )
        map.overlays.add(pointsOverlay)

        position = PositionOverlay(this) { onLocationUpdate() }
        map.overlays.add(position)

        map.addMapListener(object : MapListener {
            override fun onScroll(event: ScrollEvent?): Boolean {
                updateCenterText(); return false
            }

            override fun onZoom(event: ZoomEvent?): Boolean {
                updateCenterText(); return false
            }
        })
        updateCenterText()
    }

    private fun updateCenterText() {
        val c = map.mapCenter
        AppState.mapCenterLat = c.latitude
        AppState.mapCenterLon = c.longitude
        tvCenter.text = String.format(Locale.US, "%.5f, %.5f", c.latitude, c.longitude)
    }

    private fun openMyPoints() {
        startActivity(Intent(this, LibraryActivity::class.java))
    }

    private fun showMainMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "My points")
        pm.menu.add(0, 2, 1, "Import GPX file")
        pm.setOnMenuItemClickListener { item ->
            if (item.itemId == 1) openMyPoints() else pickGpx.launch(arrayOf("*/*"))
            true
        }
        pm.show()
    }

    /** Map selection, like Locus: pick street or satellite map. */
    private fun showMapMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(1, 1, 0, "Street map")
        pm.menu.add(1, 2, 1, "Satellite map")
        pm.menu.setGroupCheckable(1, true, true)
        pm.menu.findItem(if (satellite) 2 else 1).isChecked = true
        pm.setOnMenuItemClickListener { item ->
            setSatellite(item.itemId == 2)
            true
        }
        pm.show()
    }

    private fun setSatellite(on: Boolean) {
        if (on == satellite) return
        satellite = on
        prefs.edit().putBoolean("satellite", satellite).apply()
        map.setTileSource(if (satellite) TileSources.SATELLITE else TileSources.STREET)
    }

    // ── Points ───────────────────────────────────────────────────────────────

    private fun reloadPoints() {
        lifecycleScope.launch {
            val data = withContext(Dispatchers.IO) {
                Repo.visiblePoints() to Repo.folders().associateBy { it.name }
            }
            val showAll = prefs.getBoolean("showAll", true)
            pointsOverlay.setData(data.first, data.second, showAll)
            updateToggle(showAll, data.first.size)

            val focus = AppState.focusPointId
            if (focus >= 0) {
                AppState.focusPointId = -1
                openPoint(focus, moveMap = true)
            } else {
                selected?.let { openPoint(it.id, moveMap = false) } // refresh, it may have changed
                val noSavedPlace = prefs.getString("lat", null) == null
                if ((fitAfterLoad || (firstLoad && noSavedPlace)) && data.first.isNotEmpty()) fitTo(data.first)
            }
            fitAfterLoad = false
            firstLoad = false
            map.invalidate()
        }
    }

    private fun fitTo(pts: List<MapPoint>) {
        if (pts.size == 1) {
            map.controller.animateTo(GeoPoint(pts[0].lat, pts[0].lon), 16.0, 800L)
            return
        }
        val box = BoundingBox.fromGeoPoints(pts.map { GeoPoint(it.lat, it.lon) })
        map.post { map.zoomToBoundingBox(box.increaseByScale(1.2f), true, 80) }
    }

    private fun openPoint(id: Long, moveMap: Boolean) {
        lifecycleScope.launch {
            val p = withContext(Dispatchers.IO) { Repo.point(id) }
            if (p == null) {
                hideCard()
                return@launch
            }
            selected = p
            pointsOverlay.selected = MapPoint.from(p)
            if (moveMap) map.controller.animateTo(GeoPoint(p.lat, p.lon), max(map.zoomLevelDouble, 17.0), 800L)
            showCard(p)
            map.invalidate()
        }
    }

    private fun updateToggle(showAll: Boolean, count: Int) {
        btnToggleAll.setImageResource(if (showAll) R.drawable.ic_eye else R.drawable.ic_eye_off)
        tvFilter.text = if (showAll) "Points on map: $count" else "All points hidden"
    }

    private fun toggleAllPoints() {
        val show = !prefs.getBoolean("showAll", true)
        prefs.edit().putBoolean("showAll", show).apply()
        pointsOverlay.showAll = show
        updateToggle(show, pointsOverlay.points.size)
        map.invalidate()
        toast(if (show) "Points shown" else "All points hidden")
    }

    // ── Point card ───────────────────────────────────────────────────────────

    private fun showCard(p: GpxPoint) {
        tvName.text = p.label
        tvInfo.text = buildString {
            append(p.coords)
            p.ele?.let { append(String.format(Locale.US, "   %.0f m", it)) }
            append("\nFolder: ").append(p.folder)
            if (p.created > 0) append("\nCreated: ").append(Geo.formatDate(p.created))
            if (p.desc.isNotBlank()) append("\n").append(p.desc)
        }
        card.visibility = View.VISIBLE
    }

    private fun hideCard() {
        card.visibility = View.GONE
        selected = null
        pointsOverlay.selected = null
        map.invalidate()
    }

    private fun navigateToSelected() {
        val p = selected ?: return
        val uri = Uri.parse("geo:${p.lat},${p.lon}?q=${p.lat},${p.lon}(${Uri.encode(p.label)})")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            toast("No navigation app installed")
        }
    }

    private fun copySelected() {
        val p = selected ?: return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("coordinates", "${p.lat}, ${p.lon}"))
        toast("Coordinates copied")
    }

    // ── Buttons ──────────────────────────────────────────────────────────────

    private fun setupButtons() {
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMainMenu(it) }
        findViewById<View>(R.id.btnMyPoints).setOnClickListener { openMyPoints() }
        findViewById<View>(R.id.btnSearch).setOnClickListener {
            saveMapState()
            startActivity(Intent(this, SearchActivity::class.java))
        }
        btnToggleAll.setOnClickListener { toggleAllPoints() }
        findViewById<View>(R.id.btnLayers).setOnClickListener { showMapMenu(it) }
        findViewById<View>(R.id.btnMyLocation).setOnClickListener { onMyLocationClicked() }
        btnGps.setOnClickListener { onMyLocationClicked() }
        findViewById<View>(R.id.btnZoomIn).setOnClickListener { map.controller.zoomIn() }
        findViewById<View>(R.id.btnZoomOut).setOnClickListener { map.controller.zoomOut() }
        findViewById<View>(R.id.btnCloseCard).setOnClickListener { hideCard() }
        findViewById<View>(R.id.btnNavigate).setOnClickListener { navigateToSelected() }
        findViewById<View>(R.id.btnCopy).setOnClickListener { copySelected() }
    }

    // ── My location ──────────────────────────────────────────────────────────

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun onMyLocationClicked() {
        if (!hasLocationPermission()) {
            askLocation.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
            return
        }
        position.start()
        val here = position.myLocation
        if (here != null) {
            map.controller.animateTo(here, max(map.zoomLevelDouble, 17.0), 800L)
        } else {
            centerOnNextFix = true
            toast("Waiting for GPS…")
        }
    }

    /** Called after the user allows location access. */
    private fun enableLocation() {
        centerOnNextFix = true
        position.start()
        updateGpsIcon()
    }

    private fun onLocationUpdate() {
        updateGpsIcon()
        if (centerOnNextFix) {
            position.myLocation?.let {
                centerOnNextFix = false
                map.controller.animateTo(it, max(map.zoomLevelDouble, 17.0), 800L)
            }
        }
        map.invalidate()
    }

    /** Green dish = GPS fix available, grey = no GPS. */
    private fun updateGpsIcon() {
        btnGps.setImageResource(if (position.hasGpsFix) R.drawable.ic_gps_on else R.drawable.ic_gps_off)
    }

    // ── Import ───────────────────────────────────────────────────────────────

    private fun askFolderAndImport(uri: Uri) {
        Dialogs.importGpx(this, uri) { _, _ ->
            fitAfterLoad = true
            reloadPoints()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
