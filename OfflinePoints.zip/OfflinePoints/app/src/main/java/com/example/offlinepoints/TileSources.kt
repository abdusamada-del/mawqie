package com.example.offlinepoints

import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.MapTileIndex

/**
 * Map layers. Both come from Esri's ArcGIS servers, whose tile URLs use the
 * order zoom/y/x. Viewed tiles are cached on the phone for offline use.
 */
object TileSources {

    val STREET: OnlineTileSourceBase = esri("EsriWorldStreetMap", "World_Street_Map", "Map © Esri")

    val SATELLITE: OnlineTileSourceBase = esri("EsriWorldImagery", "World_Imagery", "Imagery © Esri")

    private fun esri(name: String, service: String, copyright: String): OnlineTileSourceBase =
        object : OnlineTileSourceBase(
            name,
            0,
            19,
            256,
            ".jpg",
            arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/$service/MapServer/tile/"),
            copyright
        ) {
            override fun getTileURLString(pMapTileIndex: Long): String =
                baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" +
                    MapTileIndex.getY(pMapTileIndex) + "/" +
                    MapTileIndex.getX(pMapTileIndex)
        }
}
