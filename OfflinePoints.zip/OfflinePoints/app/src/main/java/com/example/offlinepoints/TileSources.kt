package com.example.offlinepoints

import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.MapTileIndex

/**
 * Map layers. Both come from Esri's ArcGIS servers, whose tile URLs use the
 * order zoom/y/x. Viewed tiles are cached on the phone for offline use.
 */
object TileSources {

    val STREET: OnlineTileSourceBase = esri("EsriWorldStreetMap", "World_Street_Map", "Map © Esri")

    val SATELLITE: OnlineTileSourceBase = esri("EsriWorldImagery", "World_Imagery", "Imagery © Esri")

    /**
     * OpenStreetMap standard map, defined here (not the map engine's built-in one) so the
     * app's own name and contact are always sent, as OpenStreetMap's tile usage policy asks.
     */
    val OSM: OnlineTileSourceBase = object : OnlineTileSourceBase(
        "OsmStandard",
        0,
        19,
        256,
        ".png",
        arrayOf("https://tile.openstreetmap.org/"),
        "© OpenStreetMap contributors"
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String =
            baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" +
                MapTileIndex.getX(pMapTileIndex) + "/" +
                MapTileIndex.getY(pMapTileIndex) + ".png"
    }

    private fun esri(name: String, service: String, copyright: String): OnlineTileSourceBase =
        object : OnlineTileSourceBase(
            name,
            0,
            19,
            256,
            ".jpg",
            arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/$service/MapServer/tile/"),
            copyright
        ) {
            override fun getTileURLString(pMapTileIndex: Long): String =
                baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" +
                    MapTileIndex.getY(pMapTileIndex) + "/" +
                    MapTileIndex.getX(pMapTileIndex)
        }
}
